from django.contrib import admin
from .admin import admin_site

# Set the URL patterns to those from the ExpoAdminSite get_urls method
urlpatterns = admin_site.get_urls()
