"""
Utility functions for tabulating scores for all teams

Contains methods for compiling teams scores and depositing them into an Excel file.
"""

from django.http.response import HttpResponse
from expo.models import Expo
from judge.models import Score, Scorecard, Judge
from openpyxl import Workbook
from openpyxl.writer.excel import save_virtual_workbook
from team.models import Team


def get_team_average_scores(team: Team):
    """
    Gets the average of all metrics for the given team
    :param team: The team for which to compute the average score
    :return: A float comprised of the average scores
    """

    # Find all the Scorecards for the team
    scorecards = Scorecard.objects.filter(team=team)
    # Keep track of the number of scorecards counted in the average
    scorecard_count = 0

    cumulative_avg = 0

    for sc in scorecards:
        # Check to see if all metrics in the scorecard have been scored
        if all(score.value for score in sc.score_set.all()):
            # Accumulate average per scorecard across metrics
            scorecard_avg = sum(score.value for score in sc.score_set.all()) / len(sc.score_set.all())
            cumulative_avg += scorecard_avg
            scorecard_count += 1

    # Return average over all scorecards
    if scorecard_count > 0:
        return cumulative_avg / scorecard_count
    return 0


def get_average_judge_team_score(judge: Judge, team: Team):
    """
    Get the average score of the team assigned by the judge as well as a dict of all the assigned scores
    :param judge:
    :type judge:
    :param team:
    :type team:
    :return:  NA = (assigned, incomplete in some form), NS = (assigned judge didn't check in), the average and scores
    :rtype:
    """
    # Default value for average, which indicates the judge did not score the team.
    average = "NA"
    scores = {}

    try:
        scorecard = Scorecard.objects.filter(team=team, judge=judge)[0]
    except Scorecard.DoesNotExist:
        average = "NA"

    if not judge.is_checked_in:
        average = "NS"

    # check to see if all metrics in the scorecard have been scored
    elif all(score.value for score in scorecard.score_set.all()):
        # accumulate average per scorecard across metrics
        average = sum(score.value for score in scorecard.score_set.all()) / len(scorecard.score_set.all())

    # Set the scores for each metrics
    for score in scorecard.score_set.all():
        scores[score.metric] = score.value

    scores["average"] = average

    return average, scores


def get_team_judge_double_indexed_dict(expo: Expo):
    """
    Gets a dictionary mapping teams to judges and the Scorecard's average
    :param expo: The Expo for which to get the data
    :return: A dictionary between team_id and judge_id containing that pairing's Scorecard average
    """
    # Get all the Scorecards
    all_scorecards = Scorecard.objects.filter(judge__expo=expo)
    # Get the teams that have a project in this Expo
    all_teams = Team.objects.filter(project__expo=expo)

    team_judges_dict = {}

    for team in all_teams:
        # Reduce all_scorecards to those with this team
        team_scorecards = all_scorecards.filter(team=team)
        for scorecard in team_scorecards:
            scorecard_judge = scorecard.judge
            # Get the average and scores for the team and judge
            avg, scores = get_average_judge_team_score(scorecard_judge, team)
            # Insert the average at (team.id, scorecard_judge.id)
            team_judges_dict[team.id, scorecard_judge.id] = avg

    return team_judges_dict


def generate_team_judge_array(expo: Expo):
    """
    Gets the 2D array mapping teams and judges to their average scores in this Expo
    This matrix can be used to generate an Excel file
    :param expo: The Expo for which to generate this array
    :return:
    """
    all_judges = Judge.objects.filter(expo=expo)
    all_teams = Team.objects.filter(project__expo=expo)

    team_count = all_teams.count()
    judge_count = all_judges.count()

    # Set the indices of the header columns
    additional_metric_count = 3
    team_avg_idx = 1  # The index at which to place the team's overall average score
    team_major_idx = 2  # Where to place the team's major
    team_table_idx = 3  # Where to place the team's table

    # Create a matrix of the appropriate size
    matrix = [["." for x in range(judge_count + additional_metric_count + 1)] for y in range(team_count + 1)]

    # Fill in the header
    judge_index = additional_metric_count + 1
    for judge in all_judges:  # type: Judge
        matrix[0][judge_index] = "{group_number}. {judge}".format(group_number=judge.group, judge=str(judge))
        judge_index += 1

    # Set the headers
    matrix[0][0] = "Team name"
    matrix[0][team_avg_idx] = "Team average"
    matrix[0][team_major_idx] = "Team major"
    matrix[0][team_table_idx] = "Team table"

    # Get all the scores
    team_judge_dict = get_team_judge_double_indexed_dict(expo)

    for team_idx, team in enumerate(all_teams):
        team_idx += 1   # Offset the team index by one because of the header row
        team_row = matrix[team_idx]
        team_row[0] = str(team.name)

        # Add all the judge's scores for this team
        judge_index = additional_metric_count + 1
        for judge in all_judges:
            try:
                value = team_judge_dict[team.id, judge.id]
            except KeyError:
                value = ""
            team_row[judge_index] = value
            judge_index += 1

        # Include the team's information in the row
        team_row[team_major_idx] = team.project.major.name.__str__()
        team_row[team_table_idx] = team.project.table.__str__()
        avg_total = get_team_average_scores(team)
        team_row[team_avg_idx] = avg_total

    return matrix


def get_team_average_dict(expo: Expo):
    """
    Gets a map from team ids to their average scores
    :param expo: The Expo in which to compile scores for teams
    :return: A map from team ids to average scores
    """
    all_teams = Team.objects.filter(project__expo=expo)
    return_dict = {}
    for team in all_teams:
        return_dict[team.id] = get_team_average_scores(team)
    return return_dict


def generate_scorecard_array(expo: Expo):
    """
    Generates an array mapping all Scorecards to their Judges, Teams, and Scores
    :param expo: The Expo for which to generate this array
    :return: An array where each row represents one Scorecard
    """
    all_scorecards = Scorecard.objects.filter(judge__expo=expo)
    scorecard_count = all_scorecards.count()

    # Set the indices for the header items
    horizontal_idx_count = 11
    judge_idx = 0
    judge_group_idx = 1
    team_name_idx = 2
    team_major_idx = 3
    team_table_idx = 4
    team_average_idx = 5
    score_first_idx = 6  # The first index at which to place scores for all the metrics
    score_last_idx = 10

    # Gets an ordered listing of metrics
    metrics = Score.get_metric_array_db(Score)
    metrics_dict = dict(Score.METRICS)

    # Initialize the matrix
    matrix = [["." for x in range(horizontal_idx_count)] for y in range(scorecard_count + 1)]

    # Set the header entries
    matrix[0][judge_idx] = "Judge name"
    matrix[0][judge_group_idx] = "Judge Group Number"
    matrix[0][team_name_idx] = "Team name"
    matrix[0][team_major_idx] = "Team major"
    matrix[0][team_table_idx] = "Team table"
    matrix[0][team_average_idx] = "Team average"

    # Fill in the metrics
    metric_idx = 0
    for metric_name in metrics:
        readable_name = metrics_dict[metric_name]
        matrix[0][score_first_idx + metric_idx] = readable_name
        metric_idx += 1

    for row_idx, sc in enumerate(all_scorecards):
        judge = sc.judge
        team = sc.team

        row_idx += 1 # Offset the row index by one (to account for the header row)

        avg, scores = get_average_judge_team_score(judge, team)

        row = matrix[row_idx]

        # The values in the row
        row[judge_idx] = str(judge)
        row[judge_group_idx] = str(judge.group)
        row[team_name_idx] = team.name
        row[team_major_idx] = str(team.project.major)
        row[team_table_idx] = team.project.table
        row[team_average_idx] = avg

        # Include the scores for each metric in the row
        metric_idx = 0
        for metric_name in metrics:
            # Offset insertion by the score_first_idx
            row[score_first_idx + metric_idx] = scores[metric_name]
            metric_idx += 1

    return matrix


def generate_judge_array(expo: Expo):
    judges = expo.judge_set.all()

    num_columns = 7

    matrix = [[
        "Group number",
        "Salutation",
        "First name",
        "Last name",
        "Email",
        "Company name",
        "Is checked in?"
    ]]

    for judge in judges:
        matrix.append([
            judge.group,
            judge.salutation,
            judge.first_name,
            judge.last_name,
            judge.email,
            judge.company_name,
            "Yes" if judge.is_checked_in else "No",
        ])

    return matrix


def generate_master_xls(expo: Expo, filename: str) -> HttpResponse:
    """
    Generates an excel file contain Team and Judge information for this Expo
    :param expo: The Expo to target
    :return: An HttpResponse with an Excel attachment
    """
    data = [("By Team. All judges", generate_team_judge_array(expo)),
            ("By scorecard. All scores", generate_scorecard_array(expo)),
            ("All judges.", generate_judge_array(expo))]

    return generate_generic_xls(data, filename)


def generate_generic_xls(data: [()], filename: str) -> HttpResponse:
    """
    Generates and returns an HTTP response containing data from the incoming dictionary
    :param data:    Tuple from sheet name to the data to be entered
    :return:        HTTP response with the excel file
    """
    wb = Workbook()

    idx = 0
    for name_data_tuple in data:
        ws = wb.create_sheet(index=idx)
        ws.title = name_data_tuple[0]

        excel_data = name_data_tuple[1]

        for row in excel_data:
            ws.append(row)

        idx += 1

    # Create an HTTP response and name the Excel file that is being downloaded
    response = HttpResponse(save_virtual_workbook(wb), content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename=' + filename
    return response
