"""
Expo administration site customizations
"""

from django.contrib.admin import AdminSite
from django.contrib import admin

from django.conf.urls import url

from . import views

"""
Register models that are to show up 
"""
from expo.models import Department, Expo
from judge.models import Score, Scorecard, JudgeMajorPreference
from expo.admin import ExpoFlatPageAdmin
from django.contrib.flatpages.models import FlatPage


# Re-register FlatPageAdmin
admin.site.unregister(FlatPage)
admin.site.register(FlatPage, ExpoFlatPageAdmin)

# Register models
admin.site.register(Department)
admin.site.register(Expo)
admin.site.register(Scorecard)
admin.site.register(Score)

admin.site.disable_action('delete_selected')

"""
Custom code for custom URLs
"""


class ExpoAdminSite(AdminSite):
    """
    Represents the customized AdminSite
    """
    site_header = "GT Expo administration"


# The custom expo_admin site
admin_site = ExpoAdminSite(name='expo_admin')


# Everything below here is for the customized expo_admin site
def get_admin_urls(urls):
    """
    Overrides the get_urls method within Django's expo_admin site
    by taking the pre-existing/default urls and appending our custom
    URLs to them
    :param urls:    The pre-existing expo_admin URLs
    :return:        The pre-existing expo_admin URLs PLUS our own custom URL mappings
    """

    def get_urls():
        """
        Custom URL mappings (expo_admin authenticated)
        :return:
        """
        my_urls = [
            url(r'^scores/choose/', admin_site.admin_view(views.select_scores)),
            url(r'^export/choose/', admin_site.admin_view(views.select_export)),
            url(r'^custom/expo/change/', views.change_expo),
            url(r'^custom/(?P<year>[0-9]{4})/(?P<term>\w+)/scores/xls/$', admin_site.admin_view(views.all_scores_excel)),
            url(r'^custom/(?P<year>[0-9]{4})/(?P<term>\w+)/export/xls/$', admin_site.admin_view(views.all_team_student_information_excel)),
        ]
        return my_urls + urls

    return get_urls


# The urls to register with the expo_admin site
admin_urls = get_admin_urls(admin.site.get_urls())
# Set our ExpoAdminSite urls to the ones garnered above
admin_site.get_urls = admin_urls
