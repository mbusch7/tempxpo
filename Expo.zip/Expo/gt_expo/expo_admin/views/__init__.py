from ._export import ExpoCSVExporter
from expo.models import Expo
from django.template.response import TemplateResponse
from django.http.response import HttpResponseForbidden, HttpResponse, HttpResponseNotAllowed
from django.views.decorators.http import require_POST
from django.shortcuts import redirect
from datetime import datetime

from ..admin import admin
from expo.helpers import get_expo
from expo.models import Expo
from team.models import Team
from judge.models import Judge, Score, Scorecard
from ..utils import get_average_judge_team_score, get_team_average_scores, generate_master_xls, \
    get_team_judge_double_indexed_dict, generate_team_judge_array

from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader, Image
from .decorators import superuser_required
import logging

from ..forms import ExpoSelectionForm

# Get an instance of a logger
logger = logging.getLogger(__name__)


@superuser_required
def all_scores_excel(response, year, term):
    """
    Creates an Excel summary of a given Expo
    :param response:
    :param year:
    :param term:
    :return:
    """
    expo = get_expo(year, term)
    filename = 'Scores from {} (downloaded at {})'.format(str(expo), str(datetime.now()))
    return generate_master_xls(expo, filename + '.xls')


@require_POST
@superuser_required
def change_expo(request):
    """
    Utility view that switches the Expo in the URL string.
    :param request:
    :return:
    """
    form = ExpoSelectionForm(request.POST)
    expo = get_expo(id=form.data['expo'])
    # Where to redirect to after getting the selected Expo
    redirect_url = form.data['expo_url_redirect'].format(expo.year, expo.term)
    return redirect(redirect_url)


@superuser_required
def select_scores(request):
    """
    Allows users to select an Expo to download Excel files
    :param request:
    :return:
    """
    expo = get_expo()
    form = ExpoSelectionForm({
        'expo_url_redirect': '/admin/custom/{}/{}/scores/xls/',
        'expo': expo.id
    })
    return TemplateResponse(request, 'score_choose.html', context={'expo_selection_form': form})


@superuser_required
def select_export(request):
    expo = get_expo()
    form = ExpoSelectionForm({
        'expo_url_redirect': '/admin/custom/{}/{}/export/xls/',
        'expo': expo.id
    })
    return TemplateResponse(request, 'export_choose.html', context={'expo_selection_form': form})


@superuser_required
def all_team_student_information_excel(request, year, term):
    expo = Expo.objects.get(year=year, term=term.lower())
    exporter = ExpoCSVExporter(expo)
    return exporter.as_response
