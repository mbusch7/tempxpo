"""
Utility functions for tabulating scores for all teams
Contains methods for compiling teams scores and depositing them into an Excel file.
"""

from datetime import datetime

from django.http.response import HttpResponse
from expo.models import Expo
from openpyxl import Workbook
from openpyxl.writer.excel import save_virtual_workbook
from team.models import Team, Student
from django.shortcuts import reverse

from typing import List, Tuple, Dict


class CSVExporter(object):
    """
    Handles writing data to a CSV file.
    """
    DATETIME_FORMAT = "%I:%M:%S %p on %b %d, %Y"

    def __init__(self):
        self.workbook = Workbook()

    def get_filename(self):
        now = datetime.now().strftime(self.DATETIME_FORMAT)
        return "Export at {time}.xlsx".format(time=now)

    def _write_to_workbook(self, data: [()]) -> None:
        """
        Generates and returns an HTTP response containing data from the incoming dictionary
        :param data: A list of sheets to write to a workbook.
                Tuple[0] is the title of the worksheet
                tuple[1] is a tuple representing the header row
                Tuple[2] is the data to write in this sheet
        :return:
        """

        for i, tup in enumerate(data):
            worksheet = self.workbook.create_sheet(index=i)
            worksheet.title = tup[0]
            worksheet.append(tup[1])  # Append the header row to the worksheet
            data = tup[2]
            for row in data:
                worksheet.append(row)

    @property
    def as_response(self):
        """
        Generates and returns an HTTP response containing data from the incoming dictionary
        :return: HTTP response with the excel file
        """
        response = HttpResponse(
            save_virtual_workbook(self.workbook),
            content_type='application/vnd.ms-excel',
        )
        response['Content-Disposition'] \
            = 'attachment; filename="{filename}"'.format(filename=self.get_filename())
        return response


class ExpoCSVExporter(CSVExporter):
    """
    Handles writing Expo data to a CSV file.
    Sample usage:
        def export_view(request):
            # ...
            exporter = ExpoCSVExporter(expo)
            return exporter.as_response
    """

    def __init__(self, expo: Expo):
        super(ExpoCSVExporter, self).__init__()
        self.expo = expo

        team_header, team_data = self._get_teams()
        student_header, student_data = self._get_students()

        self._write_to_workbook([("Teams", team_header, team_data),
                                ("Students", student_header, student_data)])

    def get_filename(self):
        now = datetime.now().strftime(self.DATETIME_FORMAT)
        return "{expo} at {time}.xlsx".format(expo=self.expo, time=now)

    def _get_teams(self):
        teams = Team.objects.filter(project__expo=self.expo)
        header = [
            # Team fields
            "Team Name",
            "Email Contact",
            # Project fields
            'Project Name',
            'Project Major',
            'Primary Adviser',
            'Sponsor',
            'Description',
            'Needs Power?',
            'Has Danger?',
            'Has Noise?',
            'Is Outside?',
            'Setup',
            'Setup Time',
            'Table Number',
            'Team Link',
        ]

        team_data = []

        for team in teams:
            project = team.project
            row = [
                # Team fields
                team.name,
                team.email_contact,
                # Project fields
                project.name,
                str(project.major),
                project.primary_advisor,
                project.sponsor,
                project.description,
                project.needs_power,
                project.has_danger,
                project.has_noise,
                project.is_outside,
                project.setup,
                project.setup_time,
                project.table,
                'http://expo.gatech.edu' + reverse('project_info', kwargs={'project_id': project.id}),
            ]
            team_data.append(row)

        return header, team_data

    def _get_students(self):
        students = Student.objects.filter(team__project__expo=self.expo)
        header = [
            # Student fields
            'First Name',
            'Last Name',
            'Email',
            'Major',
            'Section',
            'Home Town',
            'Shirt Size',
            # User fields
            'Username',
            # Team fields
            'Team Name',
        ]

        student_data = []

        for student in students:
            user = getattr(student, 'user', None)
            row = [
                # Student fields
                student.first_name,
                student.last_name,
                student.email,
                str(student.major),
                student.section,
                student.home_town,
                student.shirt_size,
                # User fields
                getattr(user, 'username', None),
                # Team fields
                student.team.name,
            ]
            student_data.append(row)

        return header, student_data
