from django import forms

from expo.models import Expo


class ExpoSelectionForm(forms.Form):
    """
    Allows admin users to change expos and redirect to a new page
    """
    expo = forms.ModelChoiceField(Expo.objects.all(), label='')
    expo_url_redirect = forms.CharField(widget=forms.HiddenInput())

