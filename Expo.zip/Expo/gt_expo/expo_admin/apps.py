from django.apps import AppConfig


class ExpoAdminConfig(AppConfig):
    name = 'expo_admin'
