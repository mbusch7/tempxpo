from django.contrib import admin
from team.models import Team, Project, Student


@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_filter = (
        'project__expo',
        'project__major',
    )

    list_display = ('name', 'project', 'member_count')
    search_fields = ['name']


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_filter = (
        'expo',
    )

    list_display = ('name', 'team', 'major', 'table')
    list_editable = ('table',)
    search_fields = ['name']


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_filter = (
        'team__project__expo',
    )
    list_display = ('email', 'first_name', 'last_name')
    search_fields = ['first_name', 'last_name', 'email']
