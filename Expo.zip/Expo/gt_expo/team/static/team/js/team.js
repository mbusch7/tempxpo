/**
 * Created by Varun Agrawal on 06/03/16.
 */


String.prototype.format = function() {
    var formatted = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{'+i+'\\}', 'gi');
        formatted = formatted.replace(regexp, arguments[i]);
    }
    return formatted;
};

MAX_MEMBERS = 20;

function display_members(n){
    for(var i=n; i<MAX_MEMBERS; i++){
        $("#student-member-" + i).hide();
        $("#id_student_set-" + i + "-DELETE").prop('checked', true);
    }

    for(var i=0; i<n; i++){
        $("#student-member-" + i).show();
        $("#id_student_set-" + i + "-DELETE").prop('checked', false);
    }
}

function clear_hidden_members(n){
    for(var i=n; i<MAX_MEMBERS; i++){
        //$("#id_student_set-" + i + "-first_name").val("");
        //$("#id_student_set-" + i + "-last_name").val("");
        $("#id_student_set-" + i + "-email").val("");
        //$("#id_student_set-" + i + "-major").val("");
        //$("#id_student_set-" + i + "-section").val("");
        //$("#id_student_set-" + i + "-home_town").val("");
        //$("#id_student_set-" + i + "-shirt_size").val("");
    }
}

$(document).ready(function() {

    var N = $("#id_team-member_count :selected").text();

    display_members(N);

    $("#id_team-member_count").change(function(){
        var n = $( this ).val();

        for(var i=n; i<MAX_MEMBERS; i++){
            $("#student-member-" + i).hide();
            $("#id_student_set-" + i + "-DELETE").prop('checked', true);
        }

        for(var i=0; i<n; i++){
            $("#student-member-" + i).show();
            $("#id_student_set-" + i + "-DELETE").prop('checked', false);
        }

        clear_hidden_members(n);


    });
});

