from django.core.management.base import BaseCommand
import csv
import os
from django.conf import settings

from expo.models import Expo
from team.models import Team


class Command(BaseCommand):
    """
    Run: python manage.py assign_team_tables
    This will take the file specified by the first positional argument
    and input its data into the database.
    Positional argument MUST be ABSOLUTE file path
    """
    help = "Assigns teams to tables from a CSV file"

    def add_arguments(self, parser):
        # Assigns 'csv_path' key in options dict from first positional arguments
        parser.add_argument('csv_path', nargs='+', type=str)

    def handle(self, *args, **options):

        try:
            # Get the absolute file path
            csv_file_path = options['csv_path'][0]
        except IndexError or Exception:
            print("Missing required argument: Absolute path of CSV file.".encode('utf-8'))
            return

        print("Assigning teams to their tables from csv file...".encode('utf-8'))
        failures = assign_teams_to_tables(csv_file_path)
        if len(failures) > 0:
            print("*** FAILED TO ASSIGN {0} TEAMS ***".format(len(failures)).encode('utf-8'))
            for failed_assign in failures:
                print("\t{0}".format(failed_assign))
        print("Complete. Check the database".encode('utf-8'))


def assign_teams_to_tables(csv_file_path):
    """
    Parses CSV file and maps each team to a table
    :param csv_file_path:
    :return:
    """
    file_path = csv_file_path
    reader = csv.DictReader(open(file_path, errors='ignore', encoding='utf-8'))
    # Fill out this dictionary to map the Team's fields to the excel headers
    FORM_FIELD_MAPPING = {'team_name': 'Team name',
                          'project_table': 'Table Number'}

    current_expo = Expo.objects.get(is_current=True)
    failed_assignments = []
    for row in reader:
        team_name = row[FORM_FIELD_MAPPING['team_name']]
        try:
            team = Team.objects.get(name=team_name, project__expo=current_expo)
        except Team.DoesNotExist:
            print("Failed to find team: {0}".format(team_name).encode('utf-8'))
            failed_assignments.append(team_name)
            continue
        project = team.project
        project.table = row[FORM_FIELD_MAPPING['project_table']]
        project.save()

    return failed_assignments
