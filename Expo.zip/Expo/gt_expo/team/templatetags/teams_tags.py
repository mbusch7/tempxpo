"""
Template Tags and Custom Filters
https://djangosnippets.org/snippets/3050/
"""


from django import template
from django.utils.safestring import mark_safe
register = template.Library()


# Sources:
# - http://codegolf.stackexchange.com/questions/4707/outputting-ordinal-numbers-1st-2nd-3rd#answer-4712
# - http://stackoverflow.com/questions/9647202/ordinal-numbers-replacement
ordinal = lambda n: "%d%s" % (n, "tsnrhtdd"[(n / 10 % 10 != 1) * (n % 10 < 4) * n % 10::4])


@register.filter(name='ordinal')
def get_ordinal(numerical, zero_indexed=True):
    """
    Maps an int to its ordinal in English. 1 maps to 1st, 2 maps to 2nd, etc.
    :param numerical: The integer value
    :return: An English string representation
    """
    if zero_indexed:
        return ordinal(numerical + 1)
    else:
        return ordinal(numerical)
