from django.conf.urls import url, include

from . import views

urlpatterns = [
    url(r'^$', views.team.home, name='team-home'),
    url(r'^create/$', views.team.create, name='team-create'),
    url(r'^(?P<team_id>[0-9]+)/update/$', views.team.update, name='team-update'),
    url(r'^(?P<team_id>[0-9]+)/delete/$', views.team.delete, name='team-delete'),

    # Student URLs
    url(r'^(?P<team_id>[0-9]+)/students/$', views.student.list_all, name='team-students'),
    url(r'^(?P<team_id>[0-9]+)/students/create/$', views.student.create, name='team-student-create'),
    url(r'^(?P<team_id>[0-9]+)/students/(?P<student_id>[0-9]+)/update/$', views.student.update, name='team-student-update'),
    url(r'^(?P<team_id>[0-9]+)/students/(?P<student_id>[0-9]+)/delete/$', views.student.remove, name='team-student-delete'),
]
