from __future__ import unicode_literals

from team.models import Student, Team, Project
from django.forms import ModelForm, Form, inlineformset_factory, BaseInlineFormSet
from django.forms.utils import ErrorDict
from django import forms
from django.core.validators import RegexValidator
from django.contrib import messages
from django.forms.formsets import DELETION_FIELD_NAME, TOTAL_FORM_COUNT
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext as _, ungettext
import re
from django.contrib.auth.models import User


class TeamLookupForm(Form):
    """
    Used to lookup teams on various fields
    """
    query = forms.CharField(help_text="Query")


class TeamForm(ModelForm):
    """
    The form used to create Teams
    """

    email_contact = forms.EmailField(
        required=True,
        max_length=50,
        widget=forms.TextInput(attrs={'placeholder': 'gburdell3@gatech.edu'}),
        label='What is the primary email contact for your team?',
        help_text=None,
    )

    class Meta:
        model = Team

        fields = (
            'name',
            'email_contact',
        )

        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Yellow Jackets'}),
        }

        labels = {
            'name': "What is the name of your team?",
        }

        help_texts = {
            'name': None,
        }


class ProjectForm(ModelForm):
    """
    A form used to create Projects
    Includes custom labels for each field
    """
    class Meta:
        model = Project

        fields = (
            'name',
            'major',
            'primary_advisor',
            'sponsor',
            'description',
            'needs_power',
            'has_danger',
            'has_noise',
            'is_outside',
            'setup',
            'setup_time',
            'expo',
        )

        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Design of hinge sorting machine'}),
            'primary_advisor': forms.TextInput(attrs={'placeholder': 'Dr. Bert Bras'}),
            'sponsor': forms.TextInput(attrs={'placeholder': 'Coca-Cola'}),
            'description': forms.Textarea(attrs={'rows': 3}),
            'is_outside': forms.Textarea(attrs={'rows': 3}),
            'expo': forms.HiddenInput(),
        }

        labels = {
            'name': "What is the name of your project?",
            'major': 'What is the school under which your project comes under? This is the project discipline and not student discipline.',
            'primary_advisor': "Please provide the name of your primary faculty advisor.",
            'sponsor': 'Please provide the name of your sponsor if applicable. If you do not have a sponsor, please enter N/A.',
            'description': 'Please describe your team\'s project in two to three sentences.',
            'needs_power': "Tick if your project prototype would need electrical power at the expo",
            'has_danger': "Tick if your project demonstration would involve dangerous elements such as heat, water, smoke, or fire",
            'has_noise': "Tick if your project demonstration would produce loud noises (ex: playing an electric guitar)",
            'is_outside': "Can your project be showcased outside? If not, please justify.",
            'setup': "What type of setup does your project require?",
            'setup_time': "What is your preferred time of day to set up your project at the Expo?",
        }

        help_texts = {
            'name': None,
            'major': None,
            'primary_advisor': None,
            'sponsor': None,
            'needs_power': None,
            'has_danger': None,
            'has_noise': None,
            'is_outside': None,
            'setup_time': None,
        }


georgiatech_username_validator = RegexValidator(
    regex=r'^[A-Za-z]+[0-9]+$',
    message='Please enter a valid Georgia Tech username such as `gburdell3`.',
)


class StudentForm(ModelForm):
    """
    The form used to create Students
    """

    def __init__(self, *args, **kwargs):
        """
        Overrides default __init__ method of StudentForm in order to:
        1. Make the username field readonly if this form manipulates a database instance
        2. Set the language of the form labels appropriately depending on the grammatical person
        :param args:
        :param kwargs: Standard kwargs plus
            second_person:bool=False
                whether or not to use second-person language
                like 'your email' instead of 'the student's email'
        """
        # Pop out custom kwargs
        use_second_person_language = kwargs.pop('second_person', False)
        self.ignore_duplicate_username = kwargs.pop('ignore_duplicate_username', False)
        username_readonly = kwargs.pop('username_readonly', False)

        # Call super __init__
        super(StudentForm, self).__init__(*args, **kwargs)

        # Set username field to readonly if interacting with database object
        instance = getattr(self, 'instance', None)
        if (instance and instance.pk) or username_readonly:
            self.fields['username'].widget.attrs['readonly'] = True

        # Set labels appropriately
        if use_second_person_language:
            self.fields['email'].label = 'What is your email address?'
            self.fields['major'].label = 'What is your major?'
            self.fields['section'].label = 'What is your section?'
            self.fields['home_town'].label = 'What is your hometown?'
            self.fields['shirt_size'].label = 'What is your shirt size?'
            self.fields['username'].label='What is your Georgia Tech username?'
        else:  # Use third person language
            self.fields['email'].label = 'What is the student\'s email address?'
            self.fields['major'].label = 'What is the student\'s major?'
            self.fields['section'].label = 'What is the student\'s section?'
            self.fields['home_town'].label = 'What is the student\'s hometown?'
            self.fields['shirt_size'].label = 'What is the student\'s shirt size?'
            self.fields['username'].label='What is the student\'s Georgia Tech username?'

    def clean_username(self):
        """
        Gets the correct username for self.instance because username is immutable.
        :return: The appropriate username
        """
        instance = getattr(self, 'instance', None)
        user = getattr(instance, 'user', None)
        pk = getattr(instance, 'pk', None)

        # Get the username
        username = self.cleaned_data['username']

        if not (instance and instance.pk):
            # If there is no student instance
            # Check for a duplicate username if requested to do so
            if not self.ignore_duplicate_username and \
                    User.objects.filter(username=username).exclude(pk=pk).exists():
                raise ValidationError("User with username \"{}\" already exists.".format(username))
            elif user is None:
                # If there is no User instance, then validate the username as well
                # This call raises a validation error
                georgiatech_username_validator(username)

        return getattr(user, 'username', username)

    username = forms.CharField(
        required=True,
        max_length=30,
        widget=forms.TextInput(attrs={'placeholder': 'gburdell3'}),
        # label set in __init__
        help_text=None,
    )

    class Meta:
        model = Student

        fields = (
            'team',
            'first_name',
            'last_name',
            'email',
            'username',
            'major',
            'section',
            'home_town',
            'shirt_size',
        )

        # labels set in __init__ method

        widgets = {
            'team': forms.HiddenInput(),
            'first_name': forms.TextInput(attrs={'placeholder': 'George'}),
            'last_name': forms.TextInput(attrs={'placeholder': 'Burdell'}),
            'email': forms.TextInput(attrs={'placeholder': 'gburdell3@gatech.edu'}),
            'section': forms.TextInput(attrs={'placeholder': 'ME 4182-A'}),
            'home_town': forms.TextInput(attrs={'placeholder': 'Atlanta, GA'}),
        }

        help_texts = {
            'first_name': None,
            'last_name': None,
            'email': None,
            'section': None,
            'home_town': None,
        }
