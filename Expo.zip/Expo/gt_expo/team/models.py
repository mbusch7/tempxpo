from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from expo.models import Expo, Department, Major
from datetime import datetime


class Project(models.Model):
    """
    The project of a team that is to be displayed at the Expo
    """
    # Name of the project
    name = models.CharField(max_length=100, null=False, help_text="E.g. Design of hinge sorting machine")
    # The major of the project linked to a Department
    major = models.ForeignKey(Department, help_text="The Department this team is associated with.")
    # Name of the project advisor
    primary_advisor = models.CharField(max_length=100, help_text="E.g. Dr. Bras")
    # Name of the project sponsor
    sponsor = models.CharField(max_length=100, help_text="E.g. Coca Cola")
    # Description of the project
    description = models.TextField(null=False)
    # Does the team need power supply?
    needs_power = models.BooleanField(help_text="Whether or not this team needs a power supply.")
    # Does the team have a display monitor?
    has_display = models.BooleanField(default=False, help_text="Whether or not the team has a display monitor.")
    # Project has dangerous elements. Needs to be outside
    has_danger = models.BooleanField(help_text="Whether the project has dangerous elements or not.")
    # Project has loud noises
    has_noise = models.BooleanField(default=False, help_text="Whether the project has loud noises or not.")
    # Location of team table (inside expo venue or outside)
    is_outside = models.TextField(help_text="Can your project be showcased outside? If no, please justify.")

    SETUP_CHOICES = (("Poster Only", "Poster Only"),
                     ("Vehicle", "Vehicle"),
                     ("Floor", "Floor"),
                     ("Table Top", "Table Top"))
    # The type of setup: table, poster, specific floor space
    setup = models.CharField(max_length=50, choices=SETUP_CHOICES)

    SETUP_TIME_CHOICES = (("1pm to 2pm", "1pm to 2pm"),
                          ("2pm to 3pm", "2pm to 3pm"),
                          ("3pm to 4pm", "3pm to 4pm"))
    # Time at which to setup at the Expo
    setup_time = models.CharField(max_length=20,
                                  choices=SETUP_TIME_CHOICES,
                                  help_text="The time the project needs to be set up at the Expo.")

    # Table number during the Expo
    table = models.CharField(max_length=100, null=True, help_text="The project's table number at the Expo.")

    # The expo at which the project was displayed
    expo = models.ForeignKey(Expo, on_delete=models.CASCADE)

    def __str__(self):
        """
        The "to string" method for the project
        :return: A string representation of the project
        """
        return "{0} - Major: ({1}) - Table {2} In {3}".format(self.name, self.major.abbreviation, self.table, self.expo)


class Team(models.Model):
    """
    Represents a group of students who formed a team for the Capstone Design.
    """
    # Team Name
    name = models.CharField(max_length=100, null=False, help_text="Yellow Jackets")
    # Primary team email contact
    email_contact = models.CharField(max_length=50, help_text="The team's primary email contact.")
    # The team's project
    project = models.OneToOneField(Project, on_delete=models.CASCADE, help_text="This team's project.")
    # Did the team check into the Expo?
    is_checked_in = models.BooleanField(help_text="Whether or not the team is checked in.", default=True)
    # Eventbrite Order ID
    order_id = models.CharField(max_length=200, help_text="The order ID of the team on Eventbrite")

    def add_student(self, student: 'Student'):
        """
        Adds the given Student to this Team and saves after setting `added_to_team` to the current server time
        :param student: The student to add to this team
        """
        student.team = self
        student.added_to_team = datetime.now()
        student.save()

    def remove_student(self, student: 'Student'):
        """
        Removes the given Student from their Team and saves after setting `added_to_team` to None
        :param student: The Student to remove from the team
        """
        student.team = None
        student.added_to_team = None
        student.save()

    @property
    def leader(self) -> 'Student':
        """
        Gets a Team's leader which is defined to be the Student added to the team first (oldest by added_to_team time)
        :return: Team's leader
        """
        return self.student_set.earliest('added_to_team')

    @property
    def members(self) -> ['Student']:
        """
        Gets all the Students of this team that are not the team leader
        :return: A list of Students that are not the team leader
        """
        return self.student_set.exclude(id=self.leader.id)

    @property
    def students(self) -> ['Student']:
        """
        Gets all the students in this team ordered in terms of the time they were added to the team
        :return:
        """
        return self.student_set.order_by('added_to_team')

    @property
    def member_count(self):
        """
        Returns the number of students in this team
        """
        return self.student_set.count()

    def __str__(self):
        """
        The "to string" method for the team
        :return: A string representation of the team
        """
        return "{0} - Project: {1} - Table {2}".format(self.name, self.project.name, self.project.table)


class Student(models.Model):
    """
    Model to record each student in the Expo
    """

    # Student Details. Should be filled in using return values from CAS
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    first_name = models.CharField(max_length=100, null=False, help_text="George")
    last_name = models.CharField(max_length=100, null=False, help_text="Burdell")
    email = models.EmailField(null=False, verbose_name="GT Email ID", help_text="gburdell3@gatech.edu")
    # Student Major
    major = models.ForeignKey(Major, null=True)
    # Student Section
    section = models.CharField(max_length=20, help_text="ME 4182-A")
    home_town = models.CharField(max_length=200, help_text="Atlanta, GA")
    # The Team to which the student belongs to
    team = models.ForeignKey(Team, blank=True,
                             null=True, default=None,
                             on_delete=models.SET_NULL)
    # The time that this student was added to to the team
    added_to_team = models.DateTimeField(null=True, default=None)

    T_SHIRT_SIZE_CHOICES = (("S", "Small"),
                            ("M", "Medium"),
                            ("L", "Large"),
                            ("XL", "XL"),
                            ("XXL", "XXL"),
                            ("XXXL", "XXXL"))
    # T-Shirt size
    shirt_size = models.CharField(max_length=4,
                                  choices=T_SHIRT_SIZE_CHOICES,
                                  help_text="This student's t-shirt size.")

    # Whether or not the student has logged in with CAS to verify their account with the Expo
    is_verified = models.BooleanField(default=False,
                                      null=False,
                                      help_text='Whether or not this student has verified their account on this site')

    @property
    def is_leader(self) -> bool:
        """
        Checks if this student is the leader of this student's associated team
        :return: Whether or not this student is the leader of his/her team. If not in team, returns False.
        """
        return getattr(self.team, 'leader', None) == self

    @staticmethod
    def get_from_username(username):
        return User.objects.get(username=username.lower()).student

    @property
    def fullname(self):
        """
        Return the full name of the student as a single string.
        :return:
        """
        return "{0.first_name} {0.last_name}".format(self)

    def __str__(self):
        """
        :return: A string representation of a Student
        """
        result = "{0.first_name} {0.last_name} ({0.email})".format(self)
        if self.is_leader:
            result += " (leader)"
        return result
