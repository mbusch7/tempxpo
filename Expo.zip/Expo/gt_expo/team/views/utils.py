from expo.models import Expo
from django.utils.timezone import now
from django.contrib import messages
from django.http.response import HttpResponseRedirect
from django.shortcuts import redirect


def is_allowed_to_access(request, requested_expo, write_messages=True) -> bool:
    """
    Given a team instance, this method checks if one is allowed to access this team based on whether this team is in
    the current (is_current) Expo. This method also checks if team registration is open now.
    :param request: The HTTP request
    :param requested_expo: The requested Expo
    :param write_messages: Whether or not to write messages to the request
    :return: Whether or not access is allowed
    """
    active_expo = Expo.objects.get(is_current=True)

    access_allowed = False
    msg = ""

    if requested_expo == active_expo:
        current_time = now()

        # This is the only case in which access is allowed
        if active_expo.registration_start <= current_time <= active_expo.registration_deadline:
            access_allowed = True

        # The student is too early
        elif current_time < active_expo.registration_start:
            msg = "Team registration for the {} {} Expo " \
                  "has not opened yet. Please check back on {}" \
                .format(requested_expo.term.title(), requested_expo.year, active_expo.registration_start)

        # The student is too late
        else:  # active_expo.registration_deadline < current_time:
            msg = "The registration deadline for the {} {} Expo has past. " \
                  "You may no longer create or update team or project information." \
                .format(requested_expo.term.title(), requested_expo.year)

    else:
        msg = "You may not edit team information for the {} {} Expo." \
            .format(requested_expo.term.title(), requested_expo.year)

    if not access_allowed and write_messages:
        messages.error(request, msg)

    return access_allowed


def get_no_access_redirect() -> HttpResponseRedirect:
    return redirect('student-profile')


def has_verified_student(request, expo=None, hide_message=False):
    """
    Checks if a request's User has a verified Student associated with it.
    Validity is determined by (request.user.student is not None and request.user.student.is_verified
    :param request: The view's HTTP request
    :param expo: The current (active) expo
    :param hide_message: Whether or not to add a 'create new student account' message to the request
    :return: Tuple of (is_verified, request.user.student or None)
    """
    student = getattr(request.user, 'student', None)  # type: Student

    is_verified = getattr(student, 'is_verified', False)

    if not is_verified and not hide_message:
        messages.error(request, 'The Expo site has incomplete student information about you. '
                                'Please fill out your student information below.')

    return is_verified, student


def get_student_creation_redirect(expo=None):
    return redirect('student-profile-update')
