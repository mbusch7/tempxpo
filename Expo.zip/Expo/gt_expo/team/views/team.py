from team.models import Team, Student, Project
from team.forms import TeamForm, ProjectForm, StudentForm
from django.shortcuts import render, redirect
from .decorators import require_GET_or_POST
from expo.models import Expo
from django.contrib import messages
from django.db import transaction
from django.contrib.auth.decorators import login_required
from django.http.response import HttpResponseRedirect
from django.utils.timezone import now
from .utils import is_allowed_to_access, get_no_access_redirect, has_verified_student, get_student_creation_redirect


@login_required
def home(request, year, term):
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    teams = Team.objects.filter(student__in=[student.id], project__expo=expo)
    context = {
        'teams': teams,
        'expo': expo,
    }
    if expo.is_current:
        messages.success(request,
                         "Welcome to team registration to the {} {} Capstone Design Expo."
                         .format(expo.term.title(), expo.year))
    else:
        current_expo = Expo.objects.get(is_current=True)
        messages.warning(request, "Below is inactive team registration for the {old_expo_term} {old_expo_year} Expo. "
                                  "Currently, registration is active for the {new_expo_term} {new_expo_year} Expo."
                                .format(old_expo_term=expo.term.title(),
                                        old_expo_year=expo.year,
                                        new_expo_term=current_expo.term.title(),
                                        new_expo_year=current_expo.year))

    return render(request, 'team/home.html', context)


@require_GET_or_POST
@login_required
@transaction.atomic
def create(request, year, term):
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    team_form = TeamForm(
        data=request.POST or None,
        prefix='team',
    )
    project_form = ProjectForm(
        data=request.POST or None,
        initial={'expo': expo},
        prefix='project',
    )

    if request.method == 'POST':
        if all([team_form.is_valid(), project_form.is_valid()]):
            project = project_form.save()

            team = team_form.save(commit=False)
            team.project = project
            team.save()

            team.add_student(student)

            messages.success(request, "Successfully created team \"{}\" with project \"{}\". "
                                      "Please proceed to add students to your team.".format(team.name, project.name))
            return redirect('team-students', year=project.expo.year, term=project.expo.term, team_id=team.id)
        else:
            messages.error(request, "Please correct the errors below and "
                                    "resubmit information about your team and project.")
    context = {
        'team_form': team_form,
        'project_form': project_form,
        'expo': expo,
    }

    return render(request, 'team/create.html', context)


@require_GET_or_POST
@login_required
def update(request, year, term, team_id):
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    team = Team.objects.get(id=team_id, project__expo=expo, student__in=[student.id])

    team_form = TeamForm(
        data=request.POST or None,
        instance=team,
        prefix='team',
    )
    project_form = ProjectForm(
        data=request.POST or None,
        instance=team.project,
        prefix='project',
    )

    if request.method == 'POST':
        if all([team_form.is_valid(), project_form.is_valid()]):
            project = project_form.save()
            team_form.save()

            return redirect('team-home', year=project.expo.year, term=project.expo.term)

    context = {
        'team_form': team_form,
        'project_form': project_form,
        'expo': expo,
        'team': team,
    }

    return render(request, 'team/update.html', context)


@require_GET_or_POST
@login_required
def delete(request, year, term, team_id):
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    team = Team.objects.get(id=team_id, project__expo=expo, student__in=[student.id])

    if request.method == 'POST':
        team.project.delete()
        team.delete()
        return redirect('team-home', year=year, term=term)

    context = {
        'team': team,
        'expo': expo,
    }

    return render(request, 'team/delete.html', context)
