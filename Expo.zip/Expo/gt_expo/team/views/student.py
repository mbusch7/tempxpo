from team.models import Team, Student, Project
from team.forms import TeamForm, ProjectForm, StudentForm
from .utils import is_allowed_to_access, get_no_access_redirect, has_verified_student, get_student_creation_redirect
from django.shortcuts import render, redirect
from .decorators import require_GET_or_POST, require_GET
from expo.models import Expo
from django.contrib import messages
from django.contrib.auth.models import User
from django.db import transaction
from django.contrib.auth.decorators import login_required


@require_GET
@login_required
def list_all(request, year, term, team_id):
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    team = Team.objects.get(id=team_id, student__in=[student.id], project__expo=expo)

    # Order the students so the leader is at the top
    students = [team.leader] + list(team.members)

    student_form = StudentForm(
        data=request.POST or None,
        prefix='student',
        initial={'team': team},
    )

    context = {
        'student_form': student_form,
        'students': students,
        'team': team,
        'expo': expo,
    }
    return render(request, 'student/student_list.html', context)


@require_GET_or_POST
@login_required
@transaction.atomic
def create(request, year, term, team_id):
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    team = Team.objects.get(id=team_id, student__in=[student.id], project__expo=expo)
    student_form = StudentForm(
        data=request.POST or None,
        prefix='student',
        initial={'team': team},
        ignore_duplicate_username=True,
    )

    error = False

    if request.method == 'POST':
        if student_form.is_valid():
            new_team_member_username = student_form.cleaned_data['username'].lower()
            new_team_member_email = student_form.cleaned_data['email']

            try:
                new_team_member_user = User.objects.get(username=new_team_member_username)
            except User.DoesNotExist:
                new_team_member_user = User.objects.create_user(
                    username=new_team_member_username,
                    email=new_team_member_email,
                    password=None,
                )
                messages.success(request, "Created new user account for {}".format(new_team_member_username))

            if hasattr(new_team_member_user, 'student') and new_team_member_user.student is not None:
                # Don't overwrite the pre-existing Student
                new_team_member_student = new_team_member_user.student
            else:
                # User doesn't have a student associated with him/her
                # Create and associate a new student with `new_team_member_user`
                new_team_member_student = student_form.save(commit=False)  # type: Student
                new_team_member_student.user = new_team_member_user
                new_team_member_student.team = None
                new_team_member_student.save()

            if new_team_member_student.team is not None:
                # The new_team_member_student is already a part of a team
                new_team_member_student_team = new_team_member_student.team
                msg = "\"{student_name}\" is already a member of team \"{team_name}\". " \
                      "Please ask the team at \"{email_contact}\" to add yourself to the team.".format(
                        student_name=new_team_member_student.fullname,
                        team_name=new_team_member_student_team.name,
                        email_contact=new_team_member_student_team.email_contact
                )
                student_form.add_error('username', msg)
                messages.error(request, msg)
                error = True
            else:
                # The Student is not a part of a team so add him/her
                team.add_student(new_team_member_student)
                messages.success(request, "Successfully added a new student {}".format(new_team_member_student.fullname))

            if not error:
                return redirect('team-students', year=expo.year, term=expo.term, team_id=team.id)
        else:
            messages.error(request, "There is an error with the information you provided. "
                                    "Please correct them and resubmit.")

    context = {
        'student_form': student_form,
        'team': team,
        'expo': expo,
    }

    return render(request, 'student/create.html', context)


@require_GET_or_POST
@login_required
def update(request, year, term, team_id, student_id):
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, request_student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    team = Team.objects.get(id=team_id, student__in=[request_student.id], project__expo=expo)

    student_to_update = team.student_set.get(id=student_id)
    student_form = StudentForm(
        data=request.POST or None,
        prefix='student',
        instance=student_to_update,
        initial={'username': student_to_update.user.username},
    )

    if request.method == 'POST':
        if student_form.is_valid():
            student_to_update = student_form.save()
            messages.success(request, "Successfully updated student {}".format(student_to_update.fullname))
            return redirect('team-students', year=expo.year, term=expo.term, team_id=team.id)
        else:
            messages.error(request,
                           "There is an error with the information you provided. Please correct them and resubmit.")

    context = {
        'student_form': student_form,
        'student': student_to_update,
        'team': team,
        'expo': expo,
    }

    return render(request, 'student/update.html', context)


@require_GET_or_POST
@login_required
def remove(request, year, term, team_id, student_id):
    """
    Removes the student from the team
    """
    expo = Expo.objects.get(year=year, term=term.lower())

    is_verified, student = has_verified_student(request, expo)
    if not is_verified:
        return get_student_creation_redirect(expo)

    access_allowed = is_allowed_to_access(request, expo)
    if not access_allowed:
        return get_no_access_redirect()

    team = Team.objects.get(id=team_id, student__in=[student.id], project__expo=expo)
    student_to_remove = team.student_set.get(id=student_id)

    if request.method == 'POST':
        # Before removing this team member, we need to see if we should do one of two mutually-exclusive things:
        # 1) Mark the team for deletion because we are removing the last team member
        # 2) Find a new team member to set

        if team.student_set.count() == 1:
            # This is the last team member in the team
            delete_team = True
        else:
            # There are other team members in the team
            delete_team = False

        # Now, we can remove the student from the team
        team.remove_student(student_to_remove)

        messages.success(request,
                         "Successfully removed student {} from team {}.".format(student_to_remove.fullname, team.name))

        if delete_team:
            team.project.delete()
            team.delete()
            messages.success(request, "Successfully deleted team {}".format(team.name))

        return redirect('team-home', year=expo.year, term=expo.term)

    context = {
        'student': student_to_remove,
        'team': team,
        'expo': expo,
        'removing_self': student_to_remove.id == student.id,
        'removing_last': team.student_set.count() == 1,
    }

    return render(request, 'student/remove.html', context)

