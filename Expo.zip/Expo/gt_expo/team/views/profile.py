from team.models import Team, Student, Project
from team.forms import TeamForm, ProjectForm, StudentForm
from django.shortcuts import render, redirect
from .decorators import require_GET_or_POST, require_GET
from expo.models import Expo
from django.contrib import messages
from django.contrib.auth.models import User
from django.db import transaction
from django.contrib.auth.decorators import login_required
from .student import has_verified_student, get_student_creation_redirect


@login_required
def profile(request):

    is_verified, student = has_verified_student(request)
    if not is_verified:
        return get_student_creation_redirect()

    expo = Expo.objects.get(is_current=True)
    context = {
        'student': student,
        'expo': expo,
    }
    return render(request, 'student/profile.html', context)


@login_required
@require_GET_or_POST
def profile_update(request):
    user = request.user
    student = getattr(user, 'student', None)

    student_form = StudentForm(
        data=request.POST or None,
        prefix='user-student',
        second_person=True,
        instance=student,
        initial={'username': user.username},
        ignore_duplicate_username=True,
        username_readonly=True,
    )

    if request.method == 'POST':
        if student_form.is_valid():
            student = student_form.save(commit=False)
            # Set the student's user as this one
            student.user = user
            # Because the user has updated his/her information, set them as verified
            student.is_verified = True
            student.save()

            messages.success(request, "Successfully saved student information.")

            return redirect('student-profile')
        else:
            messages.error(request, "Please fix the form errors below and resubmit.")

    context = {
        'student_form': student_form,
        'student': student,
    }

    return render(request, 'student/profile_update.html', context)