from __future__ import unicode_literals

from django.db import models
import json


class Expo(models.Model):
    """
    Represents all the Expos that have taken place at Georgia Tech
    Run python manage.py loaddata expos to load the json file into the database
    """
    # The Year when the Expo was help
    year = models.CharField(null=False, max_length=5, help_text="The year the Expo is held in.")

    # The first element in each tuple is the actual value to be set on the model,
    # and the second element is the human-readable name.
    TERM_CHOICES = (("fall", "Fall"),
                    ("spring", "Spring"),
                    ("summer", "Summer"))

    # Record which term the Expo took place in, Fall, Spring etc
    term = models.CharField(null=False, max_length=10,
                            choices=TERM_CHOICES,
                            help_text="The academic term the Expo is held in.")

    # Convenience field to check which Expo is the current one
    is_current = models.BooleanField(help_text="Whether or not this Expo is the current one.")

    # The date of the Expo
    date = models.DateField(help_text="The date of the Expo.")

    # Date when registration for the Expo begins
    registration_start = models.DateTimeField(help_text="The date registration begins for the Expo.")
    # The last day a student can register
    registration_deadline = models.DateTimeField(help_text="The date registration closes for this Expo.")
    # Link to registration page
    team_registration_link = models.URLField(help_text="The URL where teams can register for the Expo.")
    # The ID of the event on Eventbrite which the teams use to regitser
    eventbrite_team_id = models.CharField(max_length=100, blank=True, null=True,
                                          help_text="The Eventbrite event ID for teams at this Expo.")

    # When to allow teams to start checking in to the expo
    team_checkin_start = models.DateTimeField(help_text="When teams can start to check in to this Expo.")
    # Date and time at which to discontinue team check-in
    team_checkin_end = models.DateTimeField(help_text="When teams can no longer check in to this Expo.")

    # Flag to indicate if judges are allowed to check in
    allow_judge_check_in = models.BooleanField(default=True,
                                               help_text="Whether or not to allow judges to check in.")

    # Start of team judging at the Expo
    judging_start = models.DateTimeField(help_text="When judging of teams begins.")
    # End of team judging at the Expo
    judging_close = models.DateTimeField(help_text="When team judging ends.")
    # Judge registration link
    judge_registration_link = models.URLField(null=True,
                                              help_text="The URL at which Judges can register for the Expo.")
    # The ID of the event on Eventbrite which the judges use
    eventbrite_judge_id = models.CharField(max_length=100, blank=True, null=True,
                                           help_text="The Eventbrite event ID for judges at this Expo.")
    # The maximum number of judges in a group
    judge_group_size = models.PositiveIntegerField(null=False,
                                                   default=1,
                                                   help_text="The max no. of judges that can belong to the same group")

    def __str__(self):
        """
        The to string method for the Expo
        :return:    Useful string representation of an Expo
        """
        result = "{0} {1} Expo".format(self.term.title(), self.year)
        if self.is_current:
            result += " (current)"
        return result

    def save(self, *args, **kwargs):
        """
        Create a new expo and set it to the current one. Subsequently, set all other expos to not current.
        :param args:
        :type args:
        :param kwargs:
        :type kwargs:
        :return:
        :rtype:
        """
        if self.is_current:
            try:
                temp = Expo.objects.filter(is_current=True)
                for e in temp:
                    if self != e:
                        e.is_current = False
                        e.save()
            except Expo.DoesNotExist:
                pass
        super(Expo, self).save(*args, **kwargs)


class Department(models.Model):
    """
    This is the department which supervises majors. Essentially each school.
    Run python manage.py loaddata departments to load the json file into the database
    """
    name = models.CharField(max_length=50, help_text="The name of this department.")
    abbreviation = models.CharField(max_length=5, help_text="The abbreviation of this department.")

    def __str__(self):
        """
        To string method for the Department
        :return: String representation of department
        """
        return self.name + " (" + self.abbreviation + ")"


class Major(models.Model):
    """
    Represents the group of majors of students taking eligible for the Expo
    """
    code = models.CharField(max_length=10, null=False, help_text="The abbreviation of the major.")
    name = models.CharField(max_length=100, null=False, help_text="The complete name of the major.")

    def __str__(self):
        """
        To string method for the Department
        :return: String representation of department
        """
        return "{0.name} ({0.code})".format(self)
