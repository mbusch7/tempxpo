/**
 * Created by Varun Agrawal (varunagrawal@gatech.edu) on 04/03/16.
 */

$(function(){
    $("#projects-table").tablesorter({
        // third click on the header will reset column to default - unsorted
        sortReset   : true,
        // Resets the sort direction so that clicking on an unsorted column will sort in the sortInitialOrder direction.
        sortRestart : true
    });
});