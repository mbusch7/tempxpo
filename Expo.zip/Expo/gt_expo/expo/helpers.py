from django.http import Http404
from .models import Expo


def get_expo(year=None, term=None, id=None):
    """
    Gets an expo specified by
    :param year: The year of the Expo
    :param term: The term of the Expo
    :return: An Expo matching these parameters or the current Expo
    """
    try:
        if id:
            expo = Expo.objects.get(id=id)
        elif year and term:
            expo = Expo.objects.get(year=year, term=term.lower())
        else:
            expo = Expo.objects.get(is_current=True)

        return expo

    except (Expo.DoesNotExist,):
        raise Http404("Specified expo does not exist")


EXPO_TERM_ORDERING = {
    'spring': 1,
    'summer': 2,
    'fall': 3,
}


def get_recent_expos(count=4):
    all_expos = Expo.objects.all()

    def ascending_sorting_key(e):
        return (int(e.year), EXPO_TERM_ORDERING[e.term])

    return sorted(all_expos, key=ascending_sorting_key, reverse=True)[:count]
