from django.conf.urls import url, include

import cas.views
from . import views
import team

urlpatterns = [
    url(r'^projects/$', views.projects, name="projects"),
    url(r'^projects/(?P<project_id>[0-9]+)/$', views.project_info, name="project_info"),
    url(r'^faq/$', views.faq, name="faq"),
    url(r'^social/$', views.social, name="social"),
    url(r'^contact/$', views.contact, name="contact"),
    url(r'^registration/', views.registration, name="registration"),
]
