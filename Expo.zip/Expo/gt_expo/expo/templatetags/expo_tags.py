"""
Template Tags and Custom Filters
https://djangosnippets.org/snippets/3050/
"""


from django import template
from django.utils.safestring import mark_safe
register = template.Library()


@register.filter(is_safe=True)
def label_with_classes(value, css):
    """
    Creates label of field and adds CSS fields
    Args:
        value:
        css:

    Returns:

    """
    return value.label_tag(attrs={'class': css})


@register.filter(name="css_and_help")
def css_and_help(field, css):
    """
    Add CSS classes and placeholder text to input field
    Args:
        field:
        css:

    Returns:

    """
    html = field.as_widget(attrs={"class": css})
    return _get_field_with_placeholder(field, html)


@register.filter(name='addcss')
def addcss(field, css):
    return field.as_widget(attrs={"class": css})


@register.filter("placeholder")
def help_text_as_placeholder(field):
    try:
        html = field.as_widget()
    except AttributeError:
        html = field

    return _get_field_with_placeholder(field, html)


def _get_field_with_placeholder(field, html):
    IGNORE_FIELDS = ['<textarea', '<select']

    for ignored_field in IGNORE_FIELDS:
        if ignored_field not in html:
            html_parts = html.split("/>")
            placeholder = field.help_text or field.name.title()
            html_parts.append('placeholder="{}"'.format(placeholder))
            html_parts.append(' />')
        else:
            return html
    return mark_safe(''.join(html_parts))
