from django import template
from django.core.urlresolvers import resolve

register = template.Library()


@register.simple_tag
def active(request, target_name):
    """
    Checks if the given target_name is representative of the request.path (current URL)
    :param request: The active HTTP request
    :param target_name: The desired tab-name
    :return: Whether or not the tab is active
    """
    if target_name == resolve(request.path_info).url_name \
            or target_name in request.path:
        return 'active'
    return ''
