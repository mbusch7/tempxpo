from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.mail import send_mail
from django.db.models import Q
from .helpers import *
import requests
import logging
from django.contrib.auth.models import User

from .models import *
from team.models import *

# Get an instance of a logger
logger = logging.getLogger(__name__)


def index(request):
    """
    Georgia Tech Expo Homepage
    :param request:
    :return:
    """
    logger.info("Home page requested")
    return render(request, "expo/index.html")


def projects(request):
    """
    Generate the view of all the projects that have been registered for the expo.
    GET request has params "department" and "query" for project major and search query respectively.

    :param request: The HTTP request body
    :param year:
    :param term:
    :return: Webpage with the list of filtered teams and projects
    """
    year = request.GET.get('year', None)
    term = request.GET.get('term', None)
    expo = get_expo(year, term)

    logger.info("Expo {0} {1} projects page".format(expo.term, expo.year))

    expos = get_recent_expos()

    selected_department_abbreviation = request.GET.get('department', None)
    page = int(request.GET.get('page', 1))

    if selected_department_abbreviation:
        logger.info("Getting major specific list of projects")
        try:
            selected_department = Department.objects.get(abbreviation=selected_department_abbreviation.upper())
        except Department.DoesNotExist:
            raise Http404("Specified major does not exist")

        projects_list = Project.objects.filter(expo=expo, major=selected_department)
    else:
        logger.info("Retrieving all projects")

        selected_department = None
        projects_list = Project.objects.filter(expo=expo)

    query = request.GET.get('query', None)
    if query:
        logger.info("Filtering as per query parameter {}".format(query))
        # Query for project name, team name, student name or student hometown
        projects_list = projects_list.filter(Q(name__icontains=query) |
                                             Q(team__name__icontains=query) |
                                             Q(team__student__first_name__icontains=query) |
                                             Q(team__student__last_name__icontains=query) |
                                             Q(team__student__home_town__icontains=query) |
                                             Q(sponsor__icontains=query) |
                                             Q(table__icontains=query)).distinct()

    # Get the pagination of the projects
    paginator = Paginator(projects_list.order_by('team__name'), 15)

    try:
        current_page = paginator.page(page)
    except (PageNotAnInteger, EmptyPage):
        current_page = paginator.page(1)

    projects_list = current_page.object_list

    departments = Department.objects.all()

    return render(request, 'expo/projects.html', {'projects': projects_list,
                                                  'departments': departments,
                                                  'selected_department': selected_department,
                                                  'expo': expo, 'expos': expos,
                                                  'query': query,
                                                  'paginator': paginator, 'current_page': page,
                                                  'page_has_next': current_page.has_next(),
                                                  'page_has_previous': current_page.has_previous()})


def project_info(request, year=None, term=None, project_id=None):
    """
    Get the information about a team and their project that can be displayed to the public.
    :param request: HTTP Request
    :param year: The year in which the team participated
    :param term: The term during which the team participated
    :param id: The ID of the team whose information is being requested
    :return:
    :rtype:
    """
    if project_id is None:
        raise Http404("No project specified")

    try:
        logger.info("Retrieving Project Info for team {}".format(id))

        project = Project.objects.get(id=project_id)
        team = project.team
        members = list(Student.objects.filter(team=team))

        expo = project.expo

        return render(request, 'expo/project_info.html', context={'team': team,
                                                                  'project': project,
                                                                  'members': members,
                                                                  'team_id': team.id,
                                                                  'expo': expo,
                                                                  })

    except (Project.DoesNotExist,):
        raise Http404("No Project with that ID")


def about(request):
    """
    Display information about the GT Capstone Design Expo
    :param request: HTTP Request
    :return:
    :rtype:
    """
    logger.info("About page requested")
    return render(request, "expo/about.html")


def map(request):
    """
    Show location information about the Expo and parking.
    :param request:
    :type request:
    :return:
    :rtype:
    """
    logger.info("Map page requested")
    return render(request, "expo/map.html")


def faq(request):
    """
    List of frequent asked questions about the Expo.
    :param request:
    :type request:
    :return:
    :rtype:
    """
    logger.info("FAQ page requested")
    return render(request, "expo/faq.html")


def schedule(request):
    """
    The schedule of the Expo.
    :param request:
    :type request:
    :return:
    :rtype:
    """
    logger.info("Schedule page requested")

    current_expo = get_expo()

    return render(request, "expo/schedule.html",
                  {'pageName': "{0} {1} Expo Schedule".format(current_expo.term.title(), current_expo.year),
                   'expo': current_expo})


def social(request):
    """
    Social Media feed for the Expo.
    :param request:
    :type request:
    :return:
    :rtype:
    """
    logger.info("Social/Newsfeed page requested")
    return render(request, "expo/social.html", {'pageName': "Social"})


def registration(request):
    """
    Page to show links to Team and Judge registration.
    :param request:
    :type request:
    :return:
    :rtype:
    """
    current_expo = get_expo()
    context = {
        'pageName': "Social",
        "expo": current_expo,
    }
    return render(request, "team/index.html", context)


def contact(request):
    """
    AJAX end point for Contact Us button. Sends an email to the admin.
    :param request:
    :type request:
    :return:
    :rtype:
    """
    logger.info("Handling contact request")

    try:
        config = json.load(open("expo/config.json"))
        email_config = config["email"]

        logger.info(email_config)

        name = request.POST["name"]
        email = request.POST["email"]
        message = request.POST["message"]

        recaptcha_response = request.POST["g-recaptcha-response"]

        logger.info("Verifying Captcha with Google")
        r = requests.post("https://www.google.com/recaptcha/api/siteverify",
                          data={'secret': "6LerPhoTAAAAALveJAVWXBoia0jSfXybzYdPIoXl",
                                'response': recaptcha_response})

        if json.loads(r.text)["success"]:
            logger.info("Valid Recaptcha")

            message = "{name}\n{email}\n{message}".format(name=name, email=email, message=message)

            # send_to = .append(request.POST["email"]
            sent = send_mail("Expo Contact Request", message, email_config["sender"], email_config["recipients"])

            logger.info("Sent email to admins")

        else:
            logger.error("Invalid recaptcha.")
            sent = False

        # should send an email to everyone in the admin group
        # this URL should be called via AJAX from the email_modal

        d = {'sender': name, 'sender_email': email, "success": bool(sent)}

    except Exception as e:
        d = {"success": False, "error": e}

    return HttpResponse(json.dumps(d))
