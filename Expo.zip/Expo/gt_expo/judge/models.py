from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from expo.models import Department, Expo
from team.models import Team
import uuid
from django.template.defaultfilters import urlencode


# The relationship between a single Judge and a single Team
# is maintained with a 'through' relationship between the
# Scorecard model


class Judge(models.Model):
    """
    Person who rates various teams and their projects
    """
    # Name prefix e.g. "Dr., Mrs."
    salutation = models.CharField(max_length=10, null=True)
    # First name of judge
    first_name = models.CharField(max_length=30, null=False, blank=True)
    # Last name of judge
    last_name = models.CharField(max_length=30, null=False, blank=True)
    # Email of judge
    email = models.CharField(max_length=100, null=False, blank=False)
    # Company that the judge works for
    company_name = models.CharField(max_length=1000, null=True)
    # Whether or not the judge has checked into the expo
    is_checked_in = models.BooleanField(default=False)
    # Unique code for each judge which they can use in the URL to access their judging page
    unique_code = models.UUIDField(max_length=100, blank=True, unique=True,
                                   default=uuid.uuid4,
                                   editable=False,
                                   help_text="The UUID for a judge. Used in the Judging portal URL.")
    # The Judge's Eventbrite ID
    eventbrite_id = models.CharField(max_length=50, unique=True, null=True,
                                     help_text="The judge's user ID on Eventbrite")
    # The Expo that the judge is participating in
    expo = models.ForeignKey(Expo, on_delete=models.CASCADE, help_text="The Expo this judge is judging in.")
    # Teams assigned to the judge for scoring.
    teams = models.ManyToManyField(Team, through='judge.Scorecard', help_text="Teams assigned to the judge.")
    # A judge can belong to a group so that each judge in the same group is given the same set of teams to evaluate.
    group = models.IntegerField(null=False, default=-1, help_text="The group number to which a judge belongs")

    @property
    def fullname(self):
        result = "{0} {1}".format(self.first_name, self.last_name)
        if self.salutation and self.salutation != "":
            return " ".join((self.salutation, result))
        else:
            return result

    QR_CODE_BASE_URL = "http://chart.apis.google.com/chart?cht=qr&chs=300x300&chl="

    @property
    def qr_code_url(self):
        return Judge.QR_CODE_BASE_URL + urlencode('http://expo.gatech.edu/judge/' + str(self.unique_code))

    def __str__(self):
        """
        The "to string" method for a judge.
        :return: String containing salutation (if available), first_name, and last_name
        """
        return "{0} ({1}) : {2} [{3}]".format(self.fullname, self.email, self.company_name, self.group)


class Score(models.Model):
    """
    From the expo.gatech.edu FAQ/Judge FAQ page, here are all the Scores needed (1 to 5):
    - Creativity and innovation
    - Utility
    - Quality of analysis
    - Proof of function
    - Good communication
    """
    scorecard = models.ForeignKey('Scorecard')

    # The valid options for a Score metric
    METRICS = (('creativity', 'Creativity'),
               ('presentation', 'Presentation'),
               ('proof_of_function', 'Proof of Function'),
               ('quality_of_analysis', 'Quality of Analysis'),
               ('utility', 'Utility'))

    # The metric for this Score
    metric = models.CharField(choices=METRICS, max_length=100,
                              help_text="The name of the metric this score is measuring.")
    # The value this metric is assigned
    value = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)],
                                             help_text="The value for this score.")

    def description(self):
        descriptions = {
            'creativity': "How creative is the idea or implementation.",
            'presentation': "How good is the presentation of the project.",
            'proof_of_function': "How well is the project able to function?",
            'quality_of_analysis': "How well the students have performed analyses.",
            'utility': "How do you rate the utility of this project?",
        }
        for d in descriptions:
            print(self.metric)
            if self.metric == d:
                return descriptions[d]

    def get_metric_array(self):
        """
        Gets the list of metrics as their are used in forms
        :return: The user-friendly metric names
        """
        return [pair[1] for pair in self.METRICS]

    def get_metric_array_db(self):
        """
        Gets the list of metrics as their are stored in the database
        :return: The system version of the metric names
        """
        return [pair[0] for pair in self.METRICS]

    def get_metric_friendly_name(self, m):
        """
        Gets the user-friendly version of the metric name
        :param m: The database-version of the metric
        :return: The user-friendly version of the metric
        """
        for metric in self.METRICS:
            if metric[0] == m:
                return metric[1]

    def metric_value_str(self):
        """
        Returns a simple metric-value representation of a score
        :return:
        """
        return "{0.metric} : {0.value}".format(self)

    def __str__(self):
        """
        :return: A string representation of a Score
        """
        return "Score ({0}) in scorecard between {1} and {2}".format(self.metric_value_str(),
                                                                     self.scorecard.judge,
                                                                     self.scorecard.team.name)


class JudgeMajorPreference(models.Model):
    """
    Model to hold all the Judge's preferences for majors.
    """
    # The judge for this preference
    judge = models.ForeignKey('Judge', on_delete=models.CASCADE)
    # The major preference of the judge. The prefence is for a department and not a sub-major within the school.
    major = models.ForeignKey(Department, on_delete=models.CASCADE)

    def __str__(self):
        return "Judge {1} prefers {2}".format(self.judge.id, self.judge.fullname, self.major.abbreviation)


class Scorecard(models.Model):
    """
    Each judge's scorecard for each team. We use this to connect Judges and the Team's scores
    """
    # The Team that the Judge must complete Scores for
    team = models.ForeignKey(Team, on_delete=models.CASCADE)
    # The Judge completing the Scores for a team
    judge = models.ForeignKey(Judge, on_delete=models.CASCADE)

    def __str__(self):
        """
        :return: A string representation of a Scorecard
        """
        scores = " ".join(["({0})".format(score.metric_value_str()) for score in self.score_set.all()])
        return """Scorecard: "{0}" - "{1}" | {2}""".format(self.team.name, self.judge.fullname, scores)
