from expo.filters import ExpoListFilter

from django.contrib import admin
from django.utils.safestring import mark_safe
from .models import Judge, Score, Scorecard, JudgeMajorPreference
from expo.helpers import get_expo


@admin.register(Judge)
class JudgeAdmin(admin.ModelAdmin):
    list_filter = (
        'expo',
        ('is_checked_in', admin.BooleanFieldListFilter),
        'salutation',
    )

    list_display = (
        'email',
        'salutation',
        'first_name',
        'last_name',
        'company_name',
        'group',
        'unique_code',
        'expo',
    )

    search_fields = ['first_name', 'last_name', 'email', 'group']

    def qr_code(self, instance):
        if instance.is_checked_in:
            return mark_safe(
                '<img src=' + instance.qr_code_url + '/>'
            )
        else:
            return mark_safe(
                'Judge isn\'t checked in.'
            )


@admin.register(JudgeMajorPreference)
class JudgeMajorPreferenceAdmin(admin.ModelAdmin):
    list_display = ('judge', 'major')
    search_fields = ['judge__first_name', 'judge__last_name', 'major__name']

    def get_readonly_fields(self, request, obj=None):
        return []  # [field.name for field in self.model._meta.fields]
