#!/bin/bash

HOME=/home/expo/Expo

NAME="gt_expo"                                      # Name of the application
DJANGODIR=$HOME/gt_expo                             # Django project directory
NUM_WORKERS=3                                       # how many worker processes should Gunicorn spawn
DJANGO_SETTINGS_MODULE=gt_expo.settings             # which settings file should Django use
DJANGO_WSGI_MODULE=gt_expo.wsgi                     # WSGI module name

echo "Starting $NAME as user `whoami`"

# Activate the virtual environment
echo "Initializing virtualenv"
source $HOME/expo_venv/bin/activate
export DJANGO_SETTINGS_MODULE=$DJANGO_SETTINGS_MODULE
export PYTHONPATH=$DJANGODIR:$PYTHONPATH

# Move to the directory where `manage.py` is present
cd $DJANGODIR

# Move all the static files to the `STATIC_ROOT` as defined in the settings.py file
python manage.py collectstatic --noinput

echo "Launching Gunicorn"

# Start your Django Unicorn
# Programs meant to be run under supervisor should not daemonize themselves (do not use --daemon)
exec gunicorn ${DJANGO_WSGI_MODULE} \
  --name $NAME \
  --workers $NUM_WORKERS \
  --bind 0.0.0.0:5002 \
  --log-level=debug \
  --log-file=-
