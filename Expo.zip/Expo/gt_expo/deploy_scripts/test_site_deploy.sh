#!/usr/bin/env bash

HOME=/home/expo/expo_staging

# Go to the home directory
cd $HOME

# Check if a venv is active. Deactivate if it is.
if [ -n "$VIRTUAL_ENV" ]; then
    deactivate
fi

# Activate the test venv environment
source $HOME/expo_test_venv/bin/activate

# Kill the background django server process
ps -ef | grep '/home/expo/expo_staging/expo_test_venv/bin/python manage.py' | awk '{kill -9 $2}'

# Get the latest code
git pull origin master

# Get the latest dependencies
pip install -r requirements.txt

# Apply pending migrations if any
python gt_expo/manage.py migrate

# Setup the static content
python gt_expo/manage.py collectstatic <<< yes

# Restart the Apache Reverse Proxy. NEEDS USER INPUT
sudo service httpd restart

# Run the test server
python gt_expo/manage.py runserver localhost:5003 &
