# Deploy scripts

In this folder, you'll find the scripts used to properly deploy this application in test and production settings.

* [`deploy.sh`](./deploy.sh) - Use this script to deploy the web server. This script pulls the latest code, installs requirements, and restarts the Expo site using [Supervisor](http://supervisord.org/). Ensure that Supervisor is active before running this script.
* [`launch_site.sh`](./launch_site.sh) - This script is used by Supervisor to start the web server.
* [`test_site_deploy.sh`](./test_site_deploy.sh) - This script is used to launch the test Expo site.

