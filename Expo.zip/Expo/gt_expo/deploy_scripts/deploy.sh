#!/usr/bin/env bash

# Run this file to deploy the Expo site on the webserver

HOME=/home/expo/Expo

# Go to the home directory
cd $HOME

# Activate the test venv environment
source $HOME/expo_venv/bin/activate

# Get the latest code
git pull origin master

# Get the latest dependencies
pip install -r requirements.txt

# Apply pending migrations if any
python gt_expo/manage.py migrate

# Setup the static content
python gt_expo/manage.py collectstatic <<< yes

# Use supervisor to deploy the site
supervisorctl -c config/expo_supervisor.conf restart gt_expo
