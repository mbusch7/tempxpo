"""gt_expo URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, include
from django.contrib.flatpages import views as flatpages_views
from django.contrib import admin
import cas
from cas import views
from team.views import profile

from expo_admin.admin import admin_site

urlpatterns = [
    # CAS
    url(r'^login/$', cas.views.login, name='login'),
    url(r'^logout/$', cas.views.logout, name='logout'),

    url(r'^expo_admin/', admin_site.urls),
    url(r'^profile/$', profile.profile, name="student-profile"),
    url(r'^profile/update/$', profile.profile_update, name="student-profile-update"),
    url(r'^', include('expo.urls')),
    url(r'^(?P<year>[0-9]{4})/(?P<term>\w+)/team/', include("team.urls")),

]

# URLs for static flatpages
urlpatterns += [
    url(r'^$', flatpages_views.flatpage, {'url': '/'}, name='index'),
    url(r'^about/$', flatpages_views.flatpage, {'url': '/about-us/'}, name='about'),
    url(r'^map/$', flatpages_views.flatpage, {'url': '/map/'}, name='map'),
    url(r'^schedule/$', flatpages_views.flatpage, {'url': '/schedule/'}, name='schedule'),
]
