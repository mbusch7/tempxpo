Vagrant allows developers to create uniform Linux environments across multiple operating systems.

With Vagrant, you can edit files in your favorite native editor (like PyCharm on a Windows OS) and then run the Django server from within Vagrant.

# Installation and Setup

Install [Vagrant](https://www.vagrantup.com/) and [VirtualBox](https://www.virtualbox.org/wiki/Downloads) and run:

1. `vagrant up --provider virtualbox`. This command will create a new Linux environment and will run all the setup instructions found in the [`../config/vagrant/provision.sh`](../config/vagrant/provision.sh) file. Please note that this process may take up to 10 minutes.

2. `vagrant ssh`. SSH into the Vagrant-managed virtual machine.

3. `cd /vagrant/gt_expo/`. Go to the project directory. The `/vagrant/` directory inside the VM maps to exactly the root `Expo`. Any changes made to files by programs inside the VM will be instantly reflected to files in your Host VM (the machine from which you ran `vagrant up`).

4. `source venv/bin/activate`. Activate the virtual environment for Python 3.5.

5. `python manage.py runserver 0.0.0.0:8080`. Run the Django server. With Vagrant's port forwarding feature, any server available at 8080 on the guest machine (the Vagrant VM) will be available at port 8080 on the host machine. See the `config.vm.network "forwarded_port", guest: 8080, host: 8080` setting in the [`Vagrantfile`](../Vagrantfile).

Now, visit `localhost:8080` on your host machine and see the project site as it is served from the Vagrant VM.

# Useful commands

Please check out [Vagrant's CLI documentation](https://www.vagrantup.com/docs/cli/) to learn about these commands in more detail. Here is a (brief) summary of the commands you will likely use most often:

- `vagrant up`
    - Starts the VM
- `vagrant provision` 
    - Runs the provisioning script inside the VM
- `vagrant reload` 
    - Restarts the VM
- `vagrant destroy` 
    - Deletes the VM

# Setting up Vagrant with PyCharm

You can edit the project files from within PyCharm in your host's environment and run the server from within Vagrant through SSH.

1. Make sure the Vagrant VM is running by typing in `vagrant up`

2. Go to the Project Interpreter setting within PyCharm.

3. Press the gear icon next to the Python interpreter dropdown.

4. Click on "Add remote" and select Vagrant. For the Python interpreter, type in `/vagrant/gt_expo/venv/bin/python`.

5. Save all your changes.

6. Click on the dropdown near the green "start" button in PyCharm's upper, right-hand corner. Select the Python interpreter you just set up. For the host, type `0.0.0.0` and for the port select `8081`.

7. Press the green start button and your Vagrant-powered Django server should be available at `localhost:8081` on the host machine.
