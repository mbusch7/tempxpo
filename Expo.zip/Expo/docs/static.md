# Serving Static Content

https://docs.djangoproject.com/en/1.9/howto/deployment/wsgi/modwsgi/#serving-files
http://blog.xjtian.com/post/52685286308/serving-static-files-in-django-more-complicated

Make sure each folder in the static files path has execute permission.
