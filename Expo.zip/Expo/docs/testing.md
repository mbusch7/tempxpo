# Running Django unit tests

Once you've activated the `virtualenv`, simply type the following the command line:

```commandline
python manage.py test
```

With this command, Django will create a test database in PostgreSQL and will run all the unit tests it can find.


# Writing tests

1. Take a look at the structure and formatting of the existing tests. In particular, [take a look at the `event` app's `fixtures` and `tests` directories](https://github.com/GeorgiaTech-DDI/Score/tree/master/score/event) in the Score app. Here you'll find the default testing data (called "fixtures") and a structured approach for testing the Score app's views (i.e. controllers or API endpoints). The `EventUpdateViewsTests` class is amongst the most detailed testing class in the integration test suite of either the Expo or Score apps so this is a good class to examine.
2. Ensure that each TestCase class can be run **independently** of **all** other TestCase classes.
3. Ensure that each method/function within a TestCase can be run **independently** of **all** other methods in that same test class. This is important because Django's test (and indeed Python's `unittest`) framework runs a `TestCase`'s methods alphabetically. You could label the methods alphabetically but this is generally suggested against in the Django community.

In development, we see that every data model has at least four endpoints for Creating, Reading, Updating, and Deleting ([CRUD](https://en.wikipedia.org/wiki/Create,_read,_update_and_delete)). When writing test for this app, it is important to structure tests such that each action of CRUD has it's own `TestCase` class.

# Using `coverage.py`

`coverage.py` is a tool for seeing what lines are run by the execution of a Python script. Examining coverage helps to understand what files have been examined by the existing tests.

## Running tests with coverage

```commandline
cd score
coverage run manage.py test
```

## Viewing results

You may view results with `coverage report` and you can view detailed results by generating a website with `coverage html` and opening `score/htmlcov/index.html` in your web browser.

# Continuous Integration with [CircleCI](https://circleci.com/)

We are currently using CircleCI as our continuous integration and independent testing tool. The goal with this tool is to automatically run our tests for new features so other developers can be assured that a proposed feature will not introduce bugs into the codebase.

## Setting up CircleCI

You'll need to run CircleCI builds on your own account before committing code to production code through a Pull Request.

1. [Create an account](https://circleci.com/vcs-authorize/) using GitHub login.

2. [Add a new project](https://circleci.com/projects) under your personal account. Be sure to have already forked the Expo project.

3. Click "Build Project" for the Expo app. The first build will start and will fail because we haven't set some environment variables.

3. Go to [https://circleci.com/gh/YOUR_GITHUB_USERNAME/Expo](https://circleci.com/gh/YOUR_GITHUB_USERNAME/Expo) and click on the setting icon in the upper lefthand corner. Go to "Build Setting > Environment Variable" and add the required environment variables as found in [environment.md](./environment.md).

Now, when you push a new commit, CircleCI will automatically trigger a build and, in a few minutes, you'll see the results of running `coverage run manage.py test`.
