# CAS Authentication

We use Georgia Tech's CAS authentication system to authenticate student users. 
To communicate with the CAS server, we use the [django-cas](https://github.com/kstateome/django-cas) library.
This library has not been updated, but any new updates are not important for the authentication functionality.

To get the current user, you can call:
    
    # request.user is the GT username
    student = Student.get_from_username(request.user.username)

For details on how to setup CAS with the Apache Reverse Proxy can be found [here](https://stansantiago.wordpress.com/2011/07/21/install-and-configure-mod_auth_cas-on-apache/).

Please subscribe to `gted@lists.gatech.edu` to get updates on GT's CAS systems.
