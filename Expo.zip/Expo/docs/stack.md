# Expo Site Tech Stack

This page describes our overall technology stack.

* **Programming Language**: [Python 3](https://www.python.org/downloads/)
* **Web Framework**: [Django](https://www.djangoproject.com/)
* **Web server**: [Gunicorn](http://gunicorn.org/)
* **Database**: [PostgreSQL](https://www.postgresql.org/)
* **Proxy Server**: [Apache Server](https://httpd.apache.org/)

# Why Python and Django?

Python is a programming language that is easy to use, learn and read, making it ideal for large projects such as this. The Django web framework provides us with everything we need to create a large complex web app righ out of the box thanks to its "batteries included" motto. Django is comparable to Rails in terms of power and thus makes a great case for use in the Expo app. Some of the nicer features of Django include a built-in ORM, easy dynamic dispatching of URLs, custom commands and admin functionality.
 
 We decided not to go with Rails for the Expo site (unlike the Projects site), since this allows even new programmers with experience in Python to get started on this site quickly. The Expo site is highly critical since it has non-GT users, hence we made the learning curve as flat as possible.


# What about performance?

If you are concerned about latency, then that is a non-issue since more complex projects than ours use Python and Django. The Expo site currently does not need non-blocking IO, though this can be accomplished by integrating the Tornado server. Django compares in performance with Rails, Node.js and ASP.NET, while having a very gentle learning curve.
  
  As for the database, we use PostgreSQL. PostgreSQL is one of the most advanced RDBMSes in the world and its ease of use, ample documentation and speed make it an ideal database backend. Please do not get waylaid by the new NoSQL trend. NoSQL databases for are data that is not relational. If you think about it, all the data that we use in the Expo site is relational. Students are related to Teams which are related to Projects which are related to Judges and Scores. The inherent relational nature of the data means we should be going for a Relational DataBase Management System or RDBMS.
  
  As further proof, StackOverflow, one of the busiest websites in the world, uses Microsoft SQL Server for their database needs. Our traffic is < 1% of StackOverflow's, hence performance is really not a problem here. 
  
  **If it isn't broken, don't fix it.**
