# Production

## Topics

Please read and understand these topics before continuing:

* Reverse Proxy
    * http://www.apachetutor.org/admin/reverseproxies
    * http://httpd.apache.org/docs/2.2/vhosts/examples.html

* Red Hat-related Apache
    * http://www.apachetutor.org/admin/reverseproxies
    * http://httpd.apache.org/docs/2.2/vhosts/examples.html

## Apache Server

Config files located at `/etc/httpd/conf.d`.

## Production Site Deployment

Login to the server:

1. ssh [username]@medesign.me.gatech.edu (username provided by IT Admin)
2. Password: *Provided by IT Admin*
3. `sudo /bin/su -s /bin/bash expo`
4. `cd /home/expo/Expo/`
5. Activate the virtual environment `source expo_venv/bin/activate`

To deploy the site:

- Go to the `gt_expo` directory as the `manage.py` file is in there.
- Deploy the site by running the `deploy.sh` script in the scripts directory: `bash deploy_scripts/deploy.sh`

### Supervisor

The deploy script uses Supervisor to automatically reload the Gunicorn server and deploy the Django site.
 
In case the server experiences failure, you will have to restart `supervisord` and manually start the site.

**NOTE** you should not use the deploy script since that restarts the already running django process. You want to start the process before you can begin using the deploy script.

To restart `supervisord`, go to the project root file where the `config` folder exists, and you can run:
```shell
supervisord -c config/expo_supervisor.conf
```

Then you can restart the site:
```shell
supervisorctl -c config/expo_supervisor.conf start gt_expo
```

## Test Site Deployment

Login to the server just like above.

To deploy the test site, run the script `test_site_deploy.sh` in the `gt_expo/scripts` directory

    bash test_site_deploy.sh
    
For quick test site deployment in order to check things, you can also run:

    python manage.py runserver localhost:5003
    
However this command will not make any sanity checks other than Django's standard checks.



## Server Log Files

    /var/log/httpd/access_log
    /var/log/httpd/error_log

 you have to sudo vim. (root access only)

