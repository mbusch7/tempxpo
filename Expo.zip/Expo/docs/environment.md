[Environment variables](https://en.wikipedia.org/wiki/Environment_variable) allow us to hide secret information and variable settings from the source code. This document outlines those variables and how they are used.

# `.env`

The Python package [`python-dotenv`](https://github.com/theskumar/python-dotenv) loads environment variables from a `.env` file into the environment of an application. This package helps developers maintain their own set of relevant environment variables seperate from the version-controlled source code.

 You should use the `.env` file to store all the secrets in the Expo app, such as passwords, OAuth keys and other secret keys. 

Typically a `.env` file looks like:

```text
SECRET_KEY='**************************************************'
DJANGO_SETTINGS_MODULE=gt_expo.settings

# many more variables...
```

The `.env` is typically placed in the `Expo/gt_expo/` directory alongside the `settings.py` file.

If you need access to these secret variables, please contact the lead developer.

# Blackbox

 Having secrets in plaintext is a really bad idea, because then everyone can see them and hack your system into the ground. Thus, we make use of [Blackbox](https://github.com/StackExchange/blackbox), created by the good people over at StackExchange. The idea is to use GPG keys to encrypt all the sensitive information in your repository. Refer to the Blackbox README for more information on setting up blackbox for yourself.
 

# Environment Variable Listing

Various environment variables used throughout the project to hide sensitive information from the version history of this repo. Any variable of type `string` should not have quotation marks (`"`) around it.

## Database

* `DATABASE_URL` 
    * **Type** `string`
    * **Required** `True`
    * **Description** The variable used by `dj_database_url` to properly connect to the PostgreSQL database.

* `DATABASE` 
    * **Type** `string`
    * **Required** `True`
    * **Description** The name of the database.
    
* `DATABASE_PASSWORD` 
    * **Type** `string`
    * **Required** `True`
    * **Description** The database password.

**NOTE** Vagrant automatically sets the `DATABASE_URL` setting making both the `DATABASE` and `DATABASE_PASSWORD` variables useless. The `DATABASE` and `DATABASE_PASSWORD` variables are used on the production server only.

## Django

* `DJANGO_SETTINGS_MODULE`
    * **Type** `string`
    * **Required** `False`
    * **Description** This is a Django-specific variable that tells the `manage.py` script where to find the project's settings. Typically `DJANGO_SETTINGS_MODULE=score.settings`. This is set automatically by the `manage.py` script.

* `DJANGO_DEBUG`
    * **Type** `bool`
    * **Required** `False`
    * **Description** Flag indicating whether we want debugging enabled. Value is Python int value, e.g. DJANGO_DEBUG=True for True or DJANGO_DEBUG=False for False.

* `SECRET_KEY`
    * **Type** `string`
    * **Required** `True`
    * **Description** This is the DJANGO secret key which should be hidden in production.
