Welcome to the documentation for the Georgia Tech Expo application!

# Setting up your local development environment

Follow the instructions in [`setup.md`](./setup.md).

# Contributing as a developer

After you have your development environment setup, please read through [`developers.md`](./developers.md).

# Documentation

(Please maintain this list of documentation files in alphabetical order.)

* [`cas.md`](./cas.md) - We use CAS to integrate with Georgia Tech's existing login system. Details about this are found in the `cas.md` file.
* [`commands.md`](./commands.md) - Outlines the custom management/utility commands you can use to effectively manage this site. These commands have been developed by the contributors to this site.
* [`developers.md`](./developers.md) - Outlines important developer-related comments and instruction to help you effectively contribute to this team effort.
* [`environment.md`](./environment.md) - Discusses the use of environment variables in this application and what variable you must set in order for this site to function properly.
* [`fixtures.md`](./fixtures.md) - Discusses how to use fixtures to provide initial data for this application.
* [`manual_setup.md`](./manual_setup.md) - Discusses how to setup your development environment from scratch without use of a VM.
* [`README.md`](./README.md) - The entry-point for developer-focused documentation. You're reading this right now!
* [`server.md`](server.md) - Discusses server-specific information about running this app in a production setting.
* [`stack.md`](./stack.md) - Discusses the application stack used in this application and why these choices were made.
* [`static.md`](./static.md) - Discusses how to serve static files (e.g. JavaScript, CSS, etc.) with Django.
* [`testing.md`](./testing.md) - Discusses best-practices for running unit tests and how to begin using CI.
* [`vagrant.md`](./vagrant.md) - Details on how to get started with application development using Vagrant.

# Contributors

This project is a generalization of concepts developed in the `GeorgiaTech-DDI/Expo` application. Thus, this Score project is the culmination of the work of many developers:

* [Varun Agrawal](http://www.varunagrawal.me/) - Lead developer for the Expo application.
* [Pramod Kotipalli](http://pramodk.net/) - Lead developer for the Score application. Current maintainer for the Expo application.
* [Gina Marie Holden](https://github.com/gholden3)
* [Vishakha Singh](https://github.com/vishakha94) - Creator of the original Expo application.
* [Shambhavi Mahajan](https://github.com/shambhumahajan)

Of course, this work would not be possible without the insight and management of [Dr. Amit Jariwala](https://www.linkedin.com/in/amitjariwala/), Director of Design & Innovation at the School of Mechanical Engineering.

---
&copy; 2017 Georgia Tech DDI

Georgia Institute of Technology - Director's Design Initiative
