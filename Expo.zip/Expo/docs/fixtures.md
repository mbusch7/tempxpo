[Fixtures in Django](https://docs.djangoproject.com/en/1.11/howto/initial-data/) are a great way to provide initial database records for testing or even in production (where appropriate).

**Never use real user data for fixtures.** Anonymize them before committing them to the repository.

# Generating fixtures

Here's how you may generate a fixture for a particular `Model` in a particular `app`:
```commandline
python manage.py dumpdata app.Model --indent=4 > app/fixtures/model.json
```

# Loading fixtures

```commandline
python manage.py loaddata FILENAME.json
```

# Dependencies

The provided fixture data have dependencies that reflect the choices made when authoring the database models for the Score. The parents, of a given fixture **must** be loaded before the child fixture can be loaded as well. Please examine the database models to understand how this should work.

# List all fixtures

Execute this line in bash from `Expo/gt_expo`
```commandline
find ./ -type f -name "*.json" -not -path "./venv/*"
```

## Existing fixtures

Below, you'll find a description of existing fixtures and where they are used. Dependencies are listed in order. **Note**: Every dependency below has its own dependencies and they must be listed as such. Please examine the test framework `TestCases` for examples.

If you add or modify fixtures, please add them to the [`vagrant/provision.sh`](../config/vagrant/provision.sh)  and update all the relevant documentation.

### Basic fixtures

* `expo/fixtures/sites.json` usable as `sites.json`
    * **description** Tells Django that this application is hosted under the `expo.gatech.edu` domain
    * **dependencies** `None`

* `expo/fixtures/flatpages.json` usable as `flatpages.json`
    * **description** Contains the HTML markup for the static pages that the public sees. Pages such as the `/about/`, `/map/` and index (`/`) are includes in this file. Be sure to update this file regularly as the front-end content changes.
    * **dependencies**
        * `sites.json`

### Expo app fixtures
* `expo/fixtures/expos.json` usable as `expos.json`
    * **description** Provides data about five past Expo events. This data reflects the data in the `Expo` model.
    * **dependencies** `None`
    

* `expo/fixtures/departments.json` usable as `departments.json`
    * **description** Reflects data about the `Department` model.
    * **dependencies**
        * `expos.json`
        
* `expo/fixtures/majors.json` usable as `majors.json`
    * **description** Reflects data about the `Major` model.
    * **dependencies**
        * `expos.json`
        
### Authentication fixtures

* `expo/fixtures/auth.json` usable as `auth.json`
    * **description** Provides information about 1300+ users and the relevant permissions and groups that allow the application to run properly.
    * **dependencies** `None`
        
### Team app fixtures

* `team/fixtures/projects.json` usable as `projects.json`
    * **description** Reflects data about the `Project` model.
    * **dependencies**
        * `expos.json`
        
* `team/fixtures/teams.json` usable as `teams.json`
    * **description** Reflects data about the `Team` model.
    * **dependencies**
        * `expos.json`
        * `projects.json`
        
* `team/fixtures/students.json` usable as `students.json`
    * **description** Reflects data about the `Student` model.
    * **dependencies**
        * `teams.json`
        
# Resolution order

In order to properly load this application, the preferred resolution order (to ensure a proper loading of sample data) is

* `sites.json`
* `flatpages.json`
* `expos.json`
* `departments.json`
* `majors.json`
* `auth.json`
* `projects.json`
* `teams.json`
* `students.json`

Check out the end of the [Vagrant provisioning script](../config/vagrant/provision.sh) to see this order in action.
