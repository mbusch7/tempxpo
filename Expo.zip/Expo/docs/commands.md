## Custom Management Commands

Django offers developers the ability to author custom management commands just like the in-built `runserver` or `migrate`. See [Django's documentation](https://docs.djangoproject.com/en/1.9/howto/custom-management-commands/) for more information on how to implement your own commands.

### Assign Table Numbers to Teams 

We learn which teams are assigned to which table numbers a few weeks before the Expo. To aid in the simple assignment of teams to their table numbers, we have developed a custom management command.

First, create a CSV file `team_tables.csv` with the [following header](https://github.com/GeorgiaTech-DDI/Expo/blob/master/gt_expo/team/management/commands/assign_teams_tables.py#L49) typed exactly as shown below:
```
Team name, Table Number
```

Now, you can open `team_tables.csv` in a notepad or Excel and enter all the teams' names and their corresponding table numbers (as found in the roster excel sent by the Expo coordinators). Your CSV file will look something like this:

```
Team name, Table Number
A team name, E42
Another team name, F43
```

Now, from from the command line, type in:
```cli
python manage.py assign_teams_tables \full\path\to\team_tables.csv
```

In this command, `\full\path\to\team_tables.csv` is the **full** path to the CSV file. Examine the console output to see if there are further actions needed. You may need to enter some team table numbers into the Expo app manually, a process made simple with the Expo's Admin panel.

*The code for the script can be found [here](https://github.com/GeorgiaTech-DDI/Expo/blob/master/gt_expo/team/management/commands/assign_teams_tables.py).*
