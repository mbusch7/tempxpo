Below are the steps you should follow to get your local development environment set up.

# Install the recommended software

These programs are _**highly-recommended**_ for developers to use.

* [`PyCharm Professional`](https://www.jetbrains.com/pycharm/download/) - This is hands-down the best IDE for Python development. This is a must-have software.

* [`Vagrant`](vagrant.md) - The best way to ensure that your development environment mirrors that of the production server and that of other developers.

* [`SmartGit`](http://www.syntevo.com/smartgit/) or [`SourceTree`](https://www.sourcetreeapp.com) - Provides a visual way to understand and contribute to source code revision histories.

# Get the code

Please fork the main `GeorgiaTech-DDI/Expo` repository. This repo is referred to as the `upstream` remote. Your fork of this remote is called the `origin`. Please clone your fork onto your local development machine.

# Set up development environment

You have two options here:

1. To use a VM that is easy to set up but takes much memory, follow [`vagrant.md`](./vagrant.md).
1. To use less computing resources at the expense of a longer set up time, please follow all the instructions in the [`manual_setup.md`](./manual_setup.md) file.

# Get `.env` file

Please contact the lead developer to get the `.env` file. This file contains **secret** keys and API tokens that are required for this site to run correctly. Move this file to `Expo/gt_expo/` where the `settings.py` file is located.

# Run the server

Run up the Django application run within your VM:

```cli
cd score
python manage.py runserver 0.0.0.0:8081
```
