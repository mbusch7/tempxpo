Welcome to the Director's Design Initiative! We are glad you can join the development team!

Below, you'll find a few **very important** notes that will help our team develop features in an organized and professional manner.

# Concepts

- New to Django? We highly recommend going through the tutorials on [Mastering Django](http://masteringdjango.com/).
These should get you up to speed in no time.
- [git flow](https://www.atlassian.com/git/tutorials/comparing-workflows): We use a variant of the git flow development methodology called the feature-branch workflow. Please become familiar with it.
- [MVC](https://en.wikipedia.org/wiki/Model–view–controller): This is a paradigm for software organization. Please become familiar with it. The best way to learn MVC for this project is in the context of the [Django tutorial](https://www.djangoproject.com)


# Contributing code

- **NEVER** push commits directly to the master branch. **ALWAYS** file and pull request and have another developer merge it.
- Push all new feature-branches to your fork of the main repository.

## Typical feature workflow

1. Ensure your fork's master branch is up-to-date with the main master branch with the following commands:
    1. `git checkout master` - Switch to your local `master` branch
    2. `git fetch --all` - Get all the changes from all the branches on all the remote repos
    3. `git merge upstream/master`
    4. `git push origin master` - This updates your GitHub fork's master branch
2. Checkout a new feature branch with `git checkout feature/FEATURE-NAME` where `FEATURE-NAME` is replaced with a lowercase feature name
3. Commit changes to `feature/FEATURE-NAME`:
    1. Make some changes to files in your repo
    2. Add files one-by-one with `git add FILENAME`
    3. Commit your changes with `git commit -m "A VERY DESCRIPTIVE COMMIT MESSAGE"`. Please be as descriptive (yet brief) as possible.
    4. Push your changes to your fork with `git push origin feature/FEATURE-NAME`. This will trigger a run of all Django tests by our continuous integration tool
4. File a pull request from your fork's `feature/FEATURE-NAME` branch to the main repo's `master` branch.
5. Assign the correct milestones, labels, etc. Assign at least one more developer to review your changes.
