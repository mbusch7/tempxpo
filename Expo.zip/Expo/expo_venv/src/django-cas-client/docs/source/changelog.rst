Changelog
=========

1.2.0 (Unreleased)
------------------

- Allow opt out of time delay caused by fetching PGT tickets
- Add support for gateway not returning a response
- Allow forcing service URL over HTTPS (https://github.com/kstateome/django-cas/pull/48)
- Allow user creation on first login to be optional (https://github.com/kstateome/django-cas/pull/49)

1.1.1
-----

*Released 4-23-2015*

- Add a few logging statements
- Add official change log.


Releases before 1.1.1 were tracked on GitHub https://github.com/kstateome/django-cas/releases