.. Django Cas Client documentation master file, created by
   sphinx-quickstart on Mon Apr 27 10:26:32 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Django Cas Client
=================

Django Cas Client is CAS Client maintained by the webteam at Kansas State University.

.. toctree::
   :maxdepth: 2

   gettingstarted
   contributing
   changelog




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

