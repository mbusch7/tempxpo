How to Contribute
=================

Fork and branch off of the ``develop`` branch.  Submit Pull requests back to ``kstateome:develop``.

Run The Tests
-------------

All PRs must pass unit tests.  To run the tests locally::

    pip install -r requirements-dev.txt
    python run_tests.py
