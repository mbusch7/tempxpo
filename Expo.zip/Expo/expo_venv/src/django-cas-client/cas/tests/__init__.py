from cas.tests.test_smoke import *
from cas.tests.test_backend import *
from cas.tests.test_views import *