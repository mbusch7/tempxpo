# Configuration Files


## Table of Contents
1. Apache Reverse Proxy Configuration
2. Supervisor Configuration
3. Daily Database Backup Cron Job.

These are all the configuration files needed to set up the Expo app. Each of these files are listed with their name, description and the location they belong to.

To set up these configuration files in the system, please create symlinks from the directory they belong in to the corresponding file in this directory, e.g. `ln -s file/in/this/directory /path/to/actual/config/file/symlink`

### Apache Reverse Proxy Configuration

- File name: httpd.conf
- Description: Apache Reverse Proxy Configuration File 
- Location: `/etc/httpd/conf.d/expo.conf`

### Supervisor Configuration
 
- File name: expo_supervisor.conf
- Description: Configuration file for Supervisor daemon
- Location: `/etc/supervisor/conf.d/expo.conf`
  
First we have to start the supervisord daemon. To do that, from the `gt_expo` directory, we run:

    supervisord -c ../config/expo_supervisor.conf

This will initiate the supervisor server, known as supervisord. The server will automatically run the script `launch_site.sh` and you should be able to browse the site on `expo.gatech.edu`.

Everything from henceforth can now be performed using the supervisor client program, `supervisorctl`.

To start the Expo site if it hasn't automatically started, we can run:

    supervisorctl -c ../config/expo_supervisor.conf start gt_expo

Here `gt_expo` is the name of the process for the Expo site as defined in the supervisor config.

After every new feature is implemented, we will want to restart the site. To do so, we have to first pull the latest code from Github, collect the static files and then restart Gunicorn. To restart gunicorn, simply run:

    supervisorctl -c ../config/expo_supervisor.conf restart gt_expo
  
This should reload the site with the new changes.

If you want to update the daemon's config, we can just tell `supervisorctl` to do that:

    supervisorctl -c ../config/expo_supervisor.conf update
  
And finally, to stop the site (which you should never need to do):

    supervisorctl -c ../config/expo_supervisor.conf stop gt_expo

**NOTE** On Red Hat, supervisord cannot find the config file if we symlink the file to the location given above, but it does not affect supervisord in any way. Thus, the symlinking for supervisord is optional.  

To kill the supervisord daemon, run
    
    ps -ef | grep supervisor | awk '{print $2}'
    kill -s SIGTERM <pid from above command>
  
More info on stopping the daemon can be found [here](http://supervisord.org/running.html#signals).

The best part about supervisor is that we can configure it to run on system startup, so every time the system is restarted after routine maintenance, the site comes back up automatically.
  Please refer to [this page](http://supervisord.org/running.html#running-supervisord-automatically-on-startup) in case supervisor is misbehaving and not running on system startup.

If there is some error you cannot figure out directly, be sure to check the log file `gunicorn_supervisor.log` in the logs directory and then consult StackOverflow as needed.

### Daily Database Backup Cron Job

To protect from data loss due to various reasons, we have set up a cron job on the server to take a backup of the database at midnight every night.

The cron job definition file can be found at `/etc/crontab`.

The cron job definition is:

    0 0 * * * expo pg_dump expo_db > /home/expo/Expo/db_backups/expo_db_dump.sql
    
The first five columns specify midnight of every day. `expo` is the user under which to run the command. 
`pg_dump expo_db > /home/expo/Expo/db_backups/expo_db_dump.sql` is the command which specifies that we should run the Postgres `pg_dump` command on the Expo database `expo_db` and save the results to the `db_backups` folder.
