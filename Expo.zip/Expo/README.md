# Georgia Tech Capstone Design Expo Website

Continuous Integration test status: [![CircleCI](https://circleci.com/gh/GeorgiaTech-DDI/Expo.svg?style=svg&circle-token=74be9032fa1656f8af206c5227d30bcd451f33b7)](https://circleci.com/gh/GeorgiaTech-DDI/Expo)

* Production site: [expo.gatech.edu](http://expo.gatech.edu)

* Staging site: [test.expo.me.gatech.edu](http://test.expo.me.gatech.edu/)

To get started as a developer, please checkout [`docs/README.md`](./docs/README.md). Please follow the instructions there to learn how to set up your development environment and how to contribute.

---
&copy; 2017 Georgia Tech DDI

Georgia Institute of Technology - Director's Design Initiative
